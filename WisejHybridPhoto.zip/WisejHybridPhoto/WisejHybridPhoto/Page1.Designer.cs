﻿namespace WisejHybridPhoto
{
    partial class Page1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej.NET Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Wisej.Web.Button();
            pictureBox1 = new Wisej.Web.PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new System.Drawing.Point(30, 32);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(140, 37);
            button1.TabIndex = 0;
            button1.Text = "Acquire Photo";
            button1.Click += button1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new System.Drawing.Point(30, 87);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(253, 198);
            pictureBox1.SizeMode = Wisej.Web.PictureBoxSizeMode.Zoom;
            // 
            // Page1
            // 
            Controls.Add(button1);
            Controls.Add(pictureBox1);
            Name = "Page1";
            Size = new System.Drawing.Size(1313, 475);
            Text = "Page1";
            Load += Page1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Button button1;
        private Wisej.Web.PictureBox pictureBox1;
    }
}
