﻿using System.IO;
using Wisej.Hybrid;
using Wisej.Web;

namespace WisejHybridPhoto
{
    public partial class Page1 : Page
    {
        //NewWindow NewWindow= new NewWindow();
        public Page1()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            CapturePhoto();
            


        }


        private void CapturePhoto()
        {

            if (Wisej.Hybrid.Device.Valid)
            {
                System.Drawing.Image result = null;

                if (!Device.Valid)
                {
                    return;
                }
                result = Device.Media.CapturePhoto(800, 600);
                //result = Device.Media.PickPhoto(800, 600);


                if (result != null && !this.IsDisposed && !this.pictureBox1.IsDisposed)
                {
                    this.pictureBox1.Image = result;
                }
            }
            else
            {
                Passero.Framework.Camera.CameraForm cameraForm = new Passero.Framework.Camera.CameraForm();
                cameraForm.ApplicationTempPath = Path.GetTempPath();
                cameraForm.ShowDialog();
                if (cameraForm.CameraImage != null)
                {
                    this.pictureBox1.Image = cameraForm.CameraImage;
                }
            }


        }

        private void Page1_Load(object sender, System.EventArgs e)
        {
           

        }
    }

}
