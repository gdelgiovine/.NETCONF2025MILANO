﻿using Wisej.Hybrid.Native.Controls;

namespace WisejHybridPhotoApp
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            MainPage = new HybridShell();
        }
    }
}