﻿using Microsoft.Extensions.Logging;
using Wisej.Hybrid.Native;

namespace WisejHybridPhotoApp
{
    public static class Startup
    {
        public static MauiApp Main()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                })

                // Uncomment and replace with Offline startup Type to use embedded web server.
                // .UseWisejOffline<OfflineStartup>()

                .UseWisejHybrid((config) =>
                {
                    // Uncomment to provide an offline fallback timeout.
                    // config.OfflineTimeout = 5000;

                    // Provide the startup URL for the Hybrid WebView.
                    //config.StartupUrl = "https://localhost:44391/";
                    config.StartupUrl = "https://demo.delgiovine.it/WIsejHybridPhoto/";
                });

#if DEBUG
		builder.Logging.AddDebug();
#endif

            return builder.Build();
        }
    }
}