﻿using Foundation;
using Wisej.Hybrid.Native;

namespace WisejHybridPhotoApp
{
    [Register("AppDelegate")]
    public class AppDelegate : HybridUIApplicationDelegate
    {
        protected override MauiApp CreateMauiApp() => Startup.Main();
    }
}