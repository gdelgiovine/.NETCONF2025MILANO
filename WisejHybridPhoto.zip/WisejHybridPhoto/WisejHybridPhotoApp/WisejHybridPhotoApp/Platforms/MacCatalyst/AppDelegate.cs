﻿using Foundation;

namespace WisejHybridPhotoApp
{
    [Register("AppDelegate")]
    public class AppDelegate : MauiUIApplicationDelegate
    {
        protected override MauiApp CreateMauiApp() => Startup.Main();
    }
}