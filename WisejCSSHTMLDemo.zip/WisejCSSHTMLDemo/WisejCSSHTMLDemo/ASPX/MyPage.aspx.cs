using System;
using System.Web.UI;

namespace WisejCSSHTMLDemo
{
    public partial class MyPage : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Logica di caricamento pagina
        }

        protected void btnServerSide_Click(object sender, EventArgs e)
        {
            
            lblMessage.Text = "Bottone server-side cliccato alle: " + DateTime.Now.ToString();
        }
    }
}