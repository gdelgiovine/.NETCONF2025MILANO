﻿using System;
using Wisej.Core;
using Wisej.Web;

namespace WisejCSSHTMLDemo
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            AppContext.SetSwitch("LabelSelfSize", false);

            Application.Desktop = new MyDesktop();

            //var webMethods = Application.Services.GetService<WebMethods>();
            //Window1 window = new Window1(webMethods);

            
            Window1 window = new Window1();
            window.Show();


        }
        [WebMethod]
        public static string App_Saluta(string nome)
        {
            return $"Ciao, {nome}! Benvenuti da App_Saluta!";
        }   
        //
        // You can use the entry method below
        // to receive the parameters from the URL in the args collection.
        //
        //static void Main(NameValueCollection args)
        //{
        //}
    }
}