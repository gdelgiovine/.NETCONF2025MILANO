﻿namespace WisejCSSHTMLDemo
{
    partial class Window1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej.NET Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Window1));
            this.textBox1 = new Wisej.Web.TextBox();
            this.btnApplicaCSS = new Wisej.Web.Button();
            this.javaScript1 = new Wisej.Web.JavaScript(this.components);
            this.bntChiamaJavaScript = new Wisej.Web.Button();
            this.bntChiamaWebMethod = new Wisej.Web.Button();
            this.HtmlPanel1 = new Wisej.Web.HtmlPanel();
            this.aspNetPanel1 = new Wisej.Web.AspNetPanel();
            this.canvas1 = new Wisej.Web.Canvas();
            this.btnCanvas = new Wisej.Web.Button();
            this.btnHTML = new Wisej.Web.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.CssClass = resources.GetString("textBox1.CssClass");
            this.textBox1.LabelText = "TextBox";
            this.textBox1.Location = new System.Drawing.Point(15, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(318, 53);
            this.textBox1.TabIndex = 0;
            // 
            // btnApplicaCSS
            // 
            this.btnApplicaCSS.Location = new System.Drawing.Point(339, 27);
            this.btnApplicaCSS.Name = "btnApplicaCSS";
            this.btnApplicaCSS.Size = new System.Drawing.Size(100, 38);
            this.btnApplicaCSS.TabIndex = 1;
            this.btnApplicaCSS.Text = "Applica CSS";
            this.btnApplicaCSS.Click += new System.EventHandler(this.btnApplicaCSS_Click);
            // 
            // bntChiamaJavaScript
            // 
            this.bntChiamaJavaScript.Location = new System.Drawing.Point(445, 27);
            this.bntChiamaJavaScript.Name = "bntChiamaJavaScript";
            this.bntChiamaJavaScript.Size = new System.Drawing.Size(129, 38);
            this.bntChiamaJavaScript.TabIndex = 2;
            this.bntChiamaJavaScript.Text = "Chiama Funzione JavaScript";
            this.bntChiamaJavaScript.Click += new System.EventHandler(this.bntChiamaJavaScript_Click);
            // 
            // bntChiamaWebMethod
            // 
            this.bntChiamaWebMethod.Location = new System.Drawing.Point(580, 27);
            this.bntChiamaWebMethod.Name = "bntChiamaWebMethod";
            this.bntChiamaWebMethod.Size = new System.Drawing.Size(129, 37);
            this.bntChiamaWebMethod.TabIndex = 3;
            this.bntChiamaWebMethod.Text = "Chiama WebMethod Server";
            this.bntChiamaWebMethod.Click += new System.EventHandler(this.bntChiamaWebMethod_Click);
            // 
            // HtmlPanel1
            // 
            this.HtmlPanel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.HtmlPanel1.Focusable = false;
            this.HtmlPanel1.Html = "<button onclick=\"window.FunzioneJS(\'Messaggio da bottone HTML\')\">Io sono HTML. Cl" +
    "iccami</button>";
            this.HtmlPanel1.Location = new System.Drawing.Point(15, 80);
            this.HtmlPanel1.Name = "HtmlPanel1";
            this.HtmlPanel1.Size = new System.Drawing.Size(235, 117);
            this.HtmlPanel1.TabIndex = 10;
            this.HtmlPanel1.TabStop = false;
            // 
            // aspNetPanel1
            // 
            this.aspNetPanel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.aspNetPanel1.Location = new System.Drawing.Point(257, 80);
            this.aspNetPanel1.Name = "aspNetPanel1";
            this.aspNetPanel1.PageSource = "ASPX\\MyPage.aspx";
            this.aspNetPanel1.Size = new System.Drawing.Size(235, 117);
            this.aspNetPanel1.TabIndex = 11;
            this.aspNetPanel1.Text = "aspNetPanel1";
            // 
            // canvas1
            // 
            this.canvas1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.canvas1.Location = new System.Drawing.Point(498, 80);
            this.canvas1.Name = "canvas1";
            this.canvas1.Size = new System.Drawing.Size(238, 117);
            // 
            // btnCanvas
            // 
            this.btnCanvas.Location = new System.Drawing.Point(498, 203);
            this.btnCanvas.Name = "btnCanvas";
            this.btnCanvas.Size = new System.Drawing.Size(238, 37);
            this.btnCanvas.TabIndex = 13;
            this.btnCanvas.Text = "Fa cose nel Canvas";
            this.btnCanvas.Click += new System.EventHandler(this.btnCanvas_Click);
            // 
            // btnHTML
            // 
            this.btnHTML.Location = new System.Drawing.Point(15, 203);
            this.btnHTML.Name = "btnHTML";
            this.btnHTML.Size = new System.Drawing.Size(235, 37);
            this.btnHTML.TabIndex = 14;
            this.btnHTML.Text = "Fa cose nell\'HTML";
            this.btnHTML.Click += new System.EventHandler(this.btnHTML_Click);
            // 
            // Window1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 16F);
            this.ClientSize = new System.Drawing.Size(849, 432);
            this.Controls.Add(this.btnHTML);
            this.Controls.Add(this.btnCanvas);
            this.Controls.Add(this.canvas1);
            this.Controls.Add(this.aspNetPanel1);
            this.Controls.Add(this.HtmlPanel1);
            this.Controls.Add(this.bntChiamaWebMethod);
            this.Controls.Add(this.bntChiamaJavaScript);
            this.Controls.Add(this.btnApplicaCSS);
            this.Controls.Add(this.textBox1);
            this.javaScript1.SetJavaScript(this, resources.GetString("$this.JavaScript"));
            this.Name = "Window1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Wisej.Web.Button btnApplicaCSS;
        private Wisej.Web.TextBox textBox1;
        private Wisej.Web.JavaScript javaScript1;
        private Wisej.Web.Button bntChiamaJavaScript;
        private Wisej.Web.Button bntChiamaWebMethod;
        internal Wisej.Web.HtmlPanel HtmlPanel1;
        private Wisej.Web.AspNetPanel aspNetPanel1;
        private Wisej.Web.Canvas canvas1;
        private Wisej.Web.Button btnCanvas;
        private Wisej.Web.Button btnHTML;
    }
}

