﻿using System;
using System.Drawing;
using Wisej.Core;
using Wisej.Web;

namespace WisejCSSHTMLDemo
{
    public partial class Window1 : Form
    {
        // Inietta il servizio WebMethods se uso DI
        private  IWebMethods _webMethods;

        public Window1()
        {
            InitializeComponent();


        }
        public Window1(IWebMethods webMethods)
        {
            _webMethods = webMethods;
            InitializeComponent();
            

        }

        [WebMethod]
        public void AggiornaTestoDaHtml(string nuovoTesto)
        {
            textBox1.Text = nuovoTesto;
        }


        [WebMethod]
        public string Window1_Saluta(string nome)
        {


            // Pulisce il canvas
            canvas1.ClearRect(0, 0, canvas1.Width, canvas1.Height);

            // Testo principale
            canvas1.Font = new Font("Arial", 24, FontStyle.Bold);
            canvas1.FillStyle = Color.DarkBlue;
            canvas1.TextAlign = CanvasTextAlign.Center;
            canvas1.FillText("Wisej.NET", canvas1.Width / 2, 30);

            // Sottotitolo
            canvas1.Font = new Font("Arial", 16, FontStyle.Regular);
            canvas1.FillStyle = Color.Gray;
            canvas1.FillText(".NET Conference 2025", canvas1.Width / 2, 60);

            
            return $"Ciao, {nome}! Benvenuti da Window1_Saluta!";

        }


        private void btnApplicaCSS_Click(object sender, EventArgs e)
        {
            if (this.textBox1.CssStyle == "")
            {
                string cssstyle = "background-color: yellow; color: red; font-weight: bold; font-size: 16px; border: 2px solid blue; padding: 10px; border-radius: 20px 10px 30px 5px; box-shadow: 0 0 20px rgba(0, 0, 255, 0.5);";
                this.textBox1.CssStyle = cssstyle;
                this.CssStyle = cssstyle;
                
            }
            else
            {
                this.textBox1.CssStyle = "";
                this.CssStyle = "";
            }

        }

        private void bntChiamaJavaScript_Click(object sender, EventArgs e)
        {
            this.Eval("FunzioneJS('Wisej.NET');");

        }

        private void bntChiamaWebMethod_Click(object sender, EventArgs e)
        {
            this.Eval("App.Window1.Window1_Saluta('.NET Conference 2025 Milano!', function(result){ alert(result); });");
            //this.Eval("App.App_Saluta('.NET Conference 2025 Milano!', function(result){ alert(result); });");

            

        }

        private void btnCanvas_Click(object sender, EventArgs e)
        {
            // Pulisce il canvas
            canvas1.ClearRect(0, 0, canvas1.Width, canvas1.Height);

            // Testo principale
            canvas1.Font = new Font("Arial", 24, FontStyle.Bold);
            canvas1.FillStyle = Color.DarkBlue;
            canvas1.TextAlign = CanvasTextAlign.Center;
            canvas1.FillText("Wisej.NET", canvas1.Width / 2, 30);

            // Sottotitolo
            canvas1.Font = new Font("Arial", 16, FontStyle.Regular);
            canvas1.FillStyle = Color.Gray;
            canvas1.FillText(".NET Conference 2025", canvas1.Width / 2, 60);

            // Disegna le linee
            canvas1.BeginPath();
            canvas1.MoveTo(0, 0);
            canvas1.LineTo(100, 100);
            canvas1.MoveTo(100, 0);
            canvas1.LineTo(0, 100);
            canvas1.StrokeStyle = Color.Red;
            canvas1.Stroke();
        }

        private void btnHTML_Click(object sender, EventArgs e)
        {
          
        }
    }
}
