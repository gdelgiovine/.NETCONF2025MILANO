﻿using Wisej.Web;
using Wisej.Core;

namespace WisejCSSHTMLDemo
{
    public interface IWebMethods
    {
        [WebMethod]
        string WebMethod_Saluta(string nome);
    }

    public class WebMethods : IWebMethods
    {
        [WebMethod] 
        public string WebMethod_Saluta(string nome)
        {
            return $"Ciao, {nome}! Benvenuti da WebMethod_Saluta";
        }

        
    }
}
