﻿using System;
using Wisej.Web;

namespace WisejCSSHTMLDemo
{
    public partial class MyDesktop : Desktop
    {
        public MyDesktop()
        {
            InitializeComponent();
            Application.SessionTimeout += Application_SessionTimeout;
        }

        

        private static void Application_SessionTimeout(object sender, System.ComponentModel.HandledEventArgs e)
        {
            // do something
            // suppress the built-in timeout window.
            e.Handled = true;
        }
    }
}
