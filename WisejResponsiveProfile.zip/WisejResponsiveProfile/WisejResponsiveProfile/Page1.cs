﻿using System;
using Wisej.Web;

namespace WisejResponsiveProfile
{
    public partial class Page1 : Page
    {
        public Page1()
        {
            InitializeComponent();
            Application.CultureChanged += Application_CultureChanged;
            
            // Imposta il tema corrente come selezionato
            cmbTheme.SelectedItem = Application.Theme .Name  ?? "Bootstrap-4";
        }

        private void Application_CultureChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Culture changed to: " + Application.CurrentCulture.Name);  
        }

        private void Page1_ResponsiveProfileChanged(object sender, ResponsiveProfileChangedEventArgs e)
        {
            if (e is null == false)
                this.textBox1 .Text = $"Responsive Profile changed from\n'{e.PreviousProfile.Name }' to '{e.CurrentProfile.Name  }'";
        }

        private void Page1_Load(object sender, System.EventArgs e)
        {
            Page1_ResponsiveProfileChanged(null, null);
            
        }

        private void btnItaliano_Click(object sender, System.EventArgs e)
        {
            Application.CurrentCulture = new System.Globalization.CultureInfo("it-IT");
            
            ReloadResources();
        }

        private void btnEnglish_Click(object sender, System.EventArgs e)
        {
            
            Application .CurrentCulture = new System.Globalization.CultureInfo("en-US");    
            ReloadResources();
        }


        private void ReloadResources()
        {
            // Sospende il layout per migliorare le prestazioni
            this.SuspendLayout();

            //// Rimuove tutti i controlli
            this.Controls.Clear();

            // Reinizializza i componenti con la nuova cultura
            InitializeComponent();

            // Riprende il layout
            this.ResumeLayout();

            // Forza l'aggiornamento visuale
            this.Update();
        }

        /// <summary>
        /// Cambia il tema dell'applicazione quando viene selezionato dalla ComboBox
        /// </summary>
        private void cmbTheme_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbTheme.SelectedItem != null)
            {
                string themeName = cmbTheme.SelectedItem.ToString();
                ChangeApplicationTheme(themeName);
            }
        }

        /// <summary>
        /// Cambia il tema dell'applicazione
        /// </summary>
        /// <param name="themeName">Nome del tema da applicare</param>
        private void ChangeApplicationTheme(string themeName)
        {
            if (string.IsNullOrEmpty(themeName))
                return;

            try
            {
                // Cambia il tema dell'applicazione
                Application.LoadTheme (themeName);

                // Aggiorna l'intera applicazione per applicare il nuovo tema
                
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Errore nel cambio del tema: {ex.Message}", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
