﻿namespace WisejResponsiveProfile
{
    partial class Page1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej.NET Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Page1));
            this.button1 = new Wisej.Web.Button();
            this.textBox1 = new Wisej.Web.TextBox();
            this.btnItaliano = new Wisej.Web.Button();
            this.btnEnglish = new Wisej.Web.Button();
            this.cmbTheme = new Wisej.Web.ComboBox();
            this.flowLayoutPanel1 = new Wisej.Web.FlowLayoutPanel();
            this.textBox2 = new Wisej.Web.TextBox();
            this.spacer1 = new Wisej.Web.Spacer();
            this.textBox3 = new Wisej.Web.TextBox();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.ResponsiveProfiles.Add(((Wisej.Base.ResponsiveProfile)(resources.GetObject("button1.ResponsiveProfiles"))));
            this.button1.ResponsiveProfiles.Add(((Wisej.Base.ResponsiveProfile)(resources.GetObject("button1.ResponsiveProfiles1"))));
            this.button1.ResponsiveProfiles.Add(((Wisej.Base.ResponsiveProfile)(resources.GetObject("button1.ResponsiveProfiles2"))));
            this.button1.ResponsiveProfiles.Add(((Wisej.Base.ResponsiveProfile)(resources.GetObject("button1.ResponsiveProfiles3"))));
            this.button1.ResponsiveProfiles.Add(((Wisej.Base.ResponsiveProfile)(resources.GetObject("button1.ResponsiveProfiles4"))));
            // 
            // textBox1
            // 
            resources.ApplyResources(this.textBox1, "textBox1");
            this.textBox1.Name = "textBox1";
            this.textBox1.ResponsiveProfiles.Add(((Wisej.Base.ResponsiveProfile)(resources.GetObject("textBox1.ResponsiveProfiles"))));
            // 
            // btnItaliano
            // 
            resources.ApplyResources(this.btnItaliano, "btnItaliano");
            this.btnItaliano.Name = "btnItaliano";
            this.btnItaliano.Click += new System.EventHandler(this.btnItaliano_Click);
            // 
            // btnEnglish
            // 
            resources.ApplyResources(this.btnEnglish, "btnEnglish");
            this.btnEnglish.Name = "btnEnglish";
            this.btnEnglish.Click += new System.EventHandler(this.btnEnglish_Click);
            // 
            // cmbTheme
            // 
            this.cmbTheme.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cmbTheme.Items.AddRange(new object[] {
            resources.GetString("cmbTheme.Items"),
            resources.GetString("cmbTheme.Items1"),
            resources.GetString("cmbTheme.Items2")});
            resources.ApplyResources(this.cmbTheme, "cmbTheme");
            this.cmbTheme.Name = "cmbTheme";
            this.cmbTheme.SelectedIndexChanged += new System.EventHandler(this.cmbTheme_SelectedIndexChanged);
            // 
            // flowLayoutPanel1
            // 
            resources.ApplyResources(this.flowLayoutPanel1, "flowLayoutPanel1");
            this.flowLayoutPanel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.flowLayoutPanel1.Controls.Add(this.textBox2);
            this.flowLayoutPanel1.Controls.Add(this.spacer1);
            this.flowLayoutPanel1.Controls.Add(this.textBox3);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            // 
            // textBox2
            // 
            this.flowLayoutPanel1.SetFillWeight(this.textBox2, 33);
            resources.ApplyResources(this.textBox2, "textBox2");
            this.textBox2.Name = "textBox2";
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // spacer1
            // 
            this.flowLayoutPanel1.SetFillWeight(this.spacer1, 33);
            resources.ApplyResources(this.spacer1, "spacer1");
            this.spacer1.Name = "spacer1";
            // 
            // textBox3
            // 
            this.flowLayoutPanel1.SetFillWeight(this.textBox3, 33);
            resources.ApplyResources(this.textBox3, "textBox3");
            this.textBox3.Name = "textBox3";
            // 
            // Page1
            // 
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.cmbTheme);
            this.Controls.Add(this.btnEnglish);
            this.Controls.Add(this.btnItaliano);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Name = "Page1";
            this.Load += new System.EventHandler(this.Page1_Load);
            this.ResponsiveProfileChanged += new Wisej.Web.ResponsiveProfileChangedEventHandler(this.Page1_ResponsiveProfileChanged);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Wisej.Web.Button button1;
        private Wisej.Web.TextBox textBox1;
        private Wisej.Web.Button btnItaliano;
        private Wisej.Web.Button btnEnglish;
        private Wisej.Web.ComboBox cmbTheme;
        private Wisej.Web.FlowLayoutPanel flowLayoutPanel1;
        private Wisej.Web.TextBox textBox2;
        private Wisej.Web.Spacer spacer1;
        private Wisej.Web.TextBox textBox3;
    }
}

