﻿using System;
using Dapper.Contrib.Extensions;

namespace Wisej3HotelDemo.Models
{
    [Table("Clienti")] // Dapper.Contrib attribute to map the class to the database table
    public class Cliente : Passero.Framework.ModelBase
    {
        [Key] // Dapper.Contrib attribute to indicate the primary key
        public int IdCliente { get; set; }
        public string Nome { get; set; }

        public string Cognome { get; set; }

        public string Email { get; set; }

        public string Telefono { get; set; }

        public DateTime? DataRegistrazione { get; set; }

        public string Indirizzo { get; set; }

        [Computed] // Dapper.Contrib attribute to indicate a computed property
        public string NomeCompleto => $"{IdCliente} -{Cognome} {Nome}"; // Proprietà calcolata per il nome completo  
    }

}
