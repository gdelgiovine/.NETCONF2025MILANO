﻿using System;
using Dapper.Contrib.Extensions;

namespace Wisej3HotelDemo.Models
{
   

    [Table ("Prenotazioni")] // Dapper.Contrib attribute to map the class to the database table
    public class Prenotazione : Passero.Framework.ModelBase
    {
        [Key] // Dapper.Contrib attribute to indicate the primary key
        public int IdPrenotazione { get; set; }
        
        public int IdCliente { get; set; } // Corretto: ora è int
        
        // Rimuovo IdOrigine se non necessario, oppure definisco la relazione
        public int IdCanale { get; set; } // Se serve, definire anche la classe Origine
        
        public DateTime? DataPrenotazione { get; set; }
        
        public DateTime? DataInizio { get; set; }
        
        
        public DateTime? DataFine { get; set; }
        
        
        public string Descrizione { get; set; }
        
        public string Stato { get; set; } // Esempio: "Confermato", "Annullato", "In attesa"
        public string Note { get; set; }
    }


    [Table("Camere")] // Dapper.Contrib attribute to map the class to the database table    
    public class Camera : Passero.Framework.ModelBase
    {

        [ExplicitKey] // Dapper.Contrib attribute to indicate the primary key   
        public string IdCamera { get; set; }
        
        public string Nome { get; set; }
        
        public string Descrizione { get; set; }
        
        public string Indirizzo { get; set; }
        
        public string Telefono { get; set; }
        public string TipoCamera { get; set; } = "Singola";// Esempio: "Singola", "Doppia", "Suite" 

        [Computed]
        public string NomeCompleto => $"{IdCamera} - {Nome}"; // Proprietà calcolata per il nome completo della camera  

    }

    [Table("PrenotazioniCamere")] // Dapper.Contrib attribute to map the class to the database table    
    public class PrenotazioneCamera : Passero.Framework.ModelBase
    {
        [ExplicitKey]
        public string IdCamera { get; set; }

        [ExplicitKey]
        public int IdPrenotazione { get; set; } // Corretto: ora è int
        

        public DateTime? DataInizio { get; set; }
        

        public DateTime? DataFine { get; set; }


        public string Stato { get; set; } = "A";
        public string Note { get; set; }

        [Computed] // Dapper.Contrib attribute to indicate a computed property
        public int Pernottamenti => (DataFine.HasValue && DataInizio.HasValue) ? (int)(DataFine.Value - DataInizio.Value).TotalDays : 0; // Proprietà calcolata per il numero di pernottamenti
    }


    [Table("CanaliPrenotazioni")] // Dapper.Contrib attribute to map the class to the database table    
    public class CanalePrenotazione : Passero.Framework.ModelBase
    {
        [Key]
        public int IdCanale { get; set; }
        public string Nome { get; set; } 
        public string Sigla { get; set; }
        public string Icona { get; set; }
        [Computed]
        public string NomeCompleto => $"{IdCanale} - {Nome}"; // Proprietà calcolata per il nome completo del canale di prenotazione    
    }


    [Table("vCalendarioCamere")] // Dapper.Contrib attribute to map the class to the database table    
    public class CalendarioCamere : Passero.Framework.ModelBase
    {
       
        public string IdCamera{ get; set; }
        public DateTime  Data { get; set; }
        public int OccupataDa { get; set; }
        public int IdPrenotazioneCheckIn { get; set; }
        public int IdPrenotazioneCheckOut { get; set; }
        public int IdPrenotazioneOccupanti { get; set; }
        public int CheckInGiorno { get; set; }    
        public int CheckOutGiorno { get; set; }   
        public int EventiGiorno { get; set; } // Numero di eventi per giorno    

    }

    [Table("vCalendarioCamereEsteso")] // Dapper.Contrib attribute to map the class to the database table    
    public class CalendarioCamereEsteso
    {
        public string IdCamera { get; set; }
        public DateTime Data { get; set; }
        public int OccupataDa { get; set; }
        public int CheckInGiorno { get; set; }
        public int CheckOutGiorno { get; set; }
        public int? EventiGiorno { get; set; }
        public int IdPrenotazioneCheckIn { get; set; }
        public int IdPrenotazioneCheckOut { get; set; }
        public int IdPrenotazioneOccupanti { get; set; }
        public int? IdCliente { get; set; }
        public int? IdCanale { get; set; }
        public DateTime DataPrenotazione { get; set; }
        public string CanaliPrenotazioni_Nome { get; set; }
        public string CanaliPrenotazione_Sigla { get; set; }
        public string CanaliPrenotazioni_Icona { get; set; }
        public string Clienti_Nome { get; set; }
        public string Clienti_Cognome { get; set; }
        public DateTime? DataCheckIn { get; set; }
        public DateTime? DataCheckOut { get; set; }
        public int Pernottamenti { get; set; } = 0;

        [Computed] // Dapper.Contrib attribute to indicate a computed property  
        public string Clienti_NomeCompleto => $"{Clienti_Nome} {Clienti_Cognome}";
        [Computed] // Dapper.Contrib attribute to indicate a computed property  
        public string Clienti_NomeBreve => $"{(string.IsNullOrEmpty(Clienti_Nome) ? "" : Clienti_Nome.Substring(0, 1))}{Clienti_Cognome}";

    }

}

