﻿using Wisej3HotelDemo.Views;
using System;
using Wisej.Web;

namespace Wisej3HotelDemo
{
    public partial class MainPage : Page
    {

       public Passero.Framework.ConfigurationManager ConfigurationManager = new Passero.Framework.ConfigurationManager ();

        Wisej3HotelDemo.MDIWindow  MDIWindow = new MDIWindow();
        public MainPage()
        {
            InitializeComponent();
        }


        public void Init()
        {
            Passero.Framework.ExecutionResult ER = new Passero.Framework.ExecutionResult();
            ER.Context = "HotelDemo.Init()";
            this.ConfigurationManager.FileName = AppDomain.CurrentDomain.BaseDirectory + @"\HotelDemo.ini";
            this.ConfigurationManager.Syntax = Passero.Framework.ConfigurationSyntax.INI;
            this.ConfigurationManager.ReadConfiguration();
            if (this.ConfigurationManager.ReadConfiguration() == false)
            {
                ER = this.ConfigurationManager.LastExecutionResult;
                MessageBox.Show($"Errore {ER.ResultCode}\n{ER.ResultMessage}", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            this.ConfigurationManager.DBConnections.Clear();
            this.ConfigurationManager.SetSessionConfigurationKeyValue("General", 
                                                                      "DBConnectionString", 
                                                                      this.ConfigurationManager.GetConfigurationKeyValue("General", "DBConnectionString"));

            System.Data.SqlClient.SqlConnection DBConnectionHotelDemo = new System.Data.SqlClient.SqlConnection(
            this.ConfigurationManager.GetSessionConfigurationKeyValue("General", "DBConnectionString"));
            this.ConfigurationManager.DBConnections.Add("HotelDemo", DBConnectionHotelDemo);
        }

        public void SetMDIWindow()
        {

            MDIWindow.Top = this.ToolBar.Height;
            MDIWindow.Height = this.Height - this.ToolBar.Height;
            if (this.Width < 500)
            {
                NavigationBar.CompactView = true;
            }
            else
            {
                NavigationBar.CompactView = false;
            }
            if (NavigationBar.Visible)
            {
                MDIWindow.Left = NavigationBar.Width;
                MDIWindow.Width = this.Width - NavigationBar.Width;
            }
            else
            {
                MDIWindow.Left = 0;
                MDIWindow.Width = this.Width;
            }
        }


        public void SetDesktop()
        {
            this.NavigationBar.Left = 0;
            this.NavigationBar.Top= this.ToolBar.Height;
            this.NavigationBar.Height = this.ClientSize.Height - this.ToolBar.Height;
            if (this.Width < 500)
            {
                NavigationBar.CompactView = true;
            }
            else
            {
                NavigationBar.CompactView = false;
            }
            this.pbAppLogo.Height = this.ToolBar.Height;
            this.pbAppLogo.Width = this.ToolBar.Height;
            SetMDIWindow ();

        }

        
        private void ManageNavigationBar(string ItemName)
        {
           
            if (ItemName == mnuClienti .Name)
            {

               
                //Views.vCliente vCliente  = new Views.vCliente ();
                Views.vCliente vCliente = Passero .Framework.ControlsUtilities .FormExist <Views.vCliente>("vCliente");
                if (vCliente == null)
                {
                    vCliente = new Views.vCliente();
                    vCliente.Name = "vCliente";
                    vCliente.ConfigurationManager = this.ConfigurationManager;
                    vCliente.MdiParent = this.MDIWindow;
                    vCliente.Show();
                }
                vCliente.Activate();
                vCliente.BringToFront();
            }


            if (ItemName == mnuCamere .Name)
            {
                Views.vCamera  vCamera = Passero.Framework.ControlsUtilities.FormExist<Views.vCamera>("vCamera");
                if (vCamera == null)
                {
                    vCamera = new Views.vCamera();
                    vCamera.Name = "vCamera";   
                    vCamera.ConfigurationManager = this.ConfigurationManager;
                    vCamera.MdiParent = this.MDIWindow;
                    vCamera.Show();
                }
                vCamera.Activate();
                vCamera.BringToFront();
            }

            if (ItemName == mnuPrenotazioni.Name)
            {
                Views.vPrenotazione  vPrenotazione = Passero.Framework.ControlsUtilities.FormExist<Views.vPrenotazione>("vPrenotazione");
                if (vPrenotazione == null)
                {
                    vPrenotazione = new Views.vPrenotazione();
                    vPrenotazione.Name = "vPrenotazione";
                    vPrenotazione.ConfigurationManager = this.ConfigurationManager;
                    vPrenotazione.MdiParent = this.MDIWindow;
                    vPrenotazione.Show();
                }
                
                vPrenotazione .Activate();
                vPrenotazione.BringToFront();
            }

            if (ItemName ==mnuPannelloPrenotazioni .Name)
            {
                
                Views.vPannelloPrenotazioniE vPannelloPrenotazioni = Passero.Framework.ControlsUtilities.FormExist<Views.vPannelloPrenotazioniE>("vPannelloPrenotazioni");
                if (vPannelloPrenotazioni == null)
                {
                    vPannelloPrenotazioni = new Views.vPannelloPrenotazioniE();
                    vPannelloPrenotazioni.Name = "vPannelloPrenotazioni";
                    vPannelloPrenotazioni.ConfigurationManager = this.ConfigurationManager;
                    vPannelloPrenotazioni.MdiParent = this.MDIWindow;
                    vPannelloPrenotazioni.Show();
                }
                
                vPannelloPrenotazioni.Activate();
                vPannelloPrenotazioni.BringToFront();
            }


            if (ItemName == mnuItaliano .Name)
            {
                Wisej.Web.Application.CurrentCulture = new System.Globalization.CultureInfo("it-IT");
            }

            if (ItemName == mnuInglese.Name)
            {
                Wisej.Web.Application.CurrentCulture = new System.Globalization.CultureInfo("en-US");
            }

          

        }


        private void MaiPage_Load(object sender, EventArgs e)
        {
            Application.CurrentCulture = new System.Globalization.CultureInfo("it-IT");
            MDIWindow = new MDIWindow();
            SetDesktop();

            this.MDIWindow.FormBorderStyle = FormBorderStyle.None;
            this.MDIWindow.Show();

            Init();
            //SetDesktop();
        }

        private void MaiPage_Resize(object sender, EventArgs e)
        {
            this.SuspendLayout ();  
            SetDesktop();
            this.ResumeLayout(true);
        }

      
    
        private void NavigationBar_Resize(object sender, EventArgs e)
        {
            this.SuspendLayout();
            SetDesktop();
            this.ResumeLayout(true);
        }

        private void NavigationBar_ItemClick(object sender, Wisej.Web.Ext.NavigationBar.NavigationBarItemClickEventArgs e)
        {
            ManageNavigationBar(e.Item.Name);
        }

        private void ToolBar_ButtonClick(object sender, ToolBarButtonClickEventArgs e)
        {
            if (e.Button.Name == this.tbMenuOwerFlow .Name)
            {
                if (this.NavigationBar.Visible)
                {
                    this.NavigationBar.Visible = false;
                }
                else
                {
                    this.NavigationBar.Visible = true;
                }

                SetMDIWindow();

            }

        }

        private void pbGDGLogo_DoubleClick(object sender, EventArgs e)
        {
            Wisej.Web.Application.Navigate("https://www.gabrieledelgiovine.it", "_blank");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Call("App.openKeyboard()");
        }
    }
}
