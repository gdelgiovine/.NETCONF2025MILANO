﻿namespace Wisej3HotelDemo
{
    partial class LoginPage
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej.NET Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlLogin = new Wisej.Web.Panel();
            this.label1 = new Wisej.Web.Label();
            this.btnLogin = new Wisej.Web.Button();
            this.txtPassword = new Wisej.Web.TextBox();
            this.txtUserName = new Wisej.Web.TextBox();
            this.pictureBox1 = new Wisej.Web.PictureBox();
            this.pictureBox2 = new Wisej.Web.PictureBox();
            this.pnlLogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlLogin
            // 
            this.pnlLogin.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pnlLogin.Controls.Add(this.label1);
            this.pnlLogin.Controls.Add(this.btnLogin);
            this.pnlLogin.Controls.Add(this.txtPassword);
            this.pnlLogin.Controls.Add(this.txtUserName);
            this.pnlLogin.Controls.Add(this.pictureBox1);
            this.pnlLogin.Controls.Add(this.pictureBox2);
            this.pnlLogin.HeaderAlignment = Wisej.Web.HorizontalAlignment.Center;
            this.pnlLogin.Location = new System.Drawing.Point(39, 35);
            this.pnlLogin.Name = "pnlLogin";
            this.pnlLogin.ShowCloseButton = false;
            this.pnlLogin.ShowHeader = true;
            this.pnlLogin.Size = new System.Drawing.Size(297, 358);
            this.pnlLogin.TabIndex = 0;
            this.pnlLogin.Text = "Hotel Demo";
            this.pnlLogin.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = Wisej.Web.DockStyle.Bottom;
            this.label1.Location = new System.Drawing.Point(0, 310);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(295, 18);
            this.label1.TabIndex = 5;
            this.label1.Text = "(C) 2025 Gabriele Del Giovine";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.DoubleClick += new System.EventHandler(this.label1_DoubleClick);
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(73, 218);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(153, 37);
            this.btnLogin.TabIndex = 4;
            this.btnLogin.Text = "Login";
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // txtPassword
            // 
            this.txtPassword.Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtPassword.Label.Padding = new Wisej.Web.Padding(0, 0, 0, 1);
            this.txtPassword.LabelText = "Password";
            this.txtPassword.Location = new System.Drawing.Point(73, 161);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(153, 44);
            this.txtPassword.TabIndex = 3;
            // 
            // txtUserName
            // 
            this.txtUserName.Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtUserName.Label.Padding = new Wisej.Web.Padding(0, 0, 0, 1);
            this.txtUserName.LabelText = "User Name";
            this.txtUserName.Location = new System.Drawing.Point(73, 109);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(153, 44);
            this.txtUserName.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.ImageSource = "resources\\HotelIcon2.png";
            this.pictureBox1.Location = new System.Drawing.Point(100, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.SizeMode = Wisej.Web.PictureBoxSizeMode.Zoom;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Bottom | Wisej.Web.AnchorStyles.Left) 
            | Wisej.Web.AnchorStyles.Right)));
            this.pictureBox2.ImageSource = "resources\\GDGLogo.png";
            this.pictureBox2.Location = new System.Drawing.Point(126, 273);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(45, 31);
            this.pictureBox2.SizeMode = Wisej.Web.PictureBoxSizeMode.Zoom;
            // 
            // LoginPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 19F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.Controls.Add(this.pnlLogin);
            this.Name = "LoginPage";
            this.Size = new System.Drawing.Size(1169, 636);
            this.pnlLogin.ResumeLayout(false);
            this.pnlLogin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel pnlLogin;
        private Wisej.Web.PictureBox pictureBox1;
        private Wisej.Web.Button btnLogin;
        private Wisej.Web.TextBox txtPassword;
        private Wisej.Web.TextBox txtUserName;
        private Wisej.Web.PictureBox pictureBox2;
        private Wisej.Web.Label label1;
    }
}
