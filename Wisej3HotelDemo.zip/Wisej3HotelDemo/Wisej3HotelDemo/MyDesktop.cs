﻿using System;
using Wisej.Web;

namespace WisejGridDemo
{
	public partial class MyDesktop : Desktop
	{
		public MyDesktop()
		{
			InitializeComponent();
		}
	}
}
