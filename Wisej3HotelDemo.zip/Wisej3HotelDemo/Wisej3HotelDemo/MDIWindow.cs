﻿using System;
using Wisej.Hybrid;
using Wisej.Web;


namespace Wisej3HotelDemo
{
    public partial class MDIWindow : Form
    {
        public MDIWindow()
        {
            InitializeComponent();
            this.lblRuntimeAppInfo.Text = Passero.Framework.Utilities.GetApplicationRuntimeInfo();
            //if (Device.Valid )
            //{   
            //    this.lblRuntimeAppInfo.Text += $"Hybrid Active"; 
            //}

            this.pbPasseroLogo.CenterToParent();
            this.pbPasseroLogo.Anchor = AnchorStyles.None;

        }

        private void pbGDGLogo_DoubleClick(object sender, EventArgs e)
        {
            Wisej.Web.Application.Navigate("https://www.gabrieledelgiovine.it", "_blank");
            
            //Application.OpenWindow(“/”, “_blank”,””, null);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Wisej.Web.Application.Navigate("https://www.gabrieledelgiovine.it", "_blank");
        }
    }
}
