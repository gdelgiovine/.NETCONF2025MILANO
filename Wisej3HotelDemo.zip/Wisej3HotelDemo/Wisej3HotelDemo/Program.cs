﻿using Wisej.Web;

namespace Wisej3HotelDemo
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {

            LoginPage window = new LoginPage();
            window.Show();
            //Application.MainPage = new MainPage();
        }

        //
        // You can use the entry method below
        // to receive the parameters from the URL in the args collection.
        //
        //static void Main(NameValueCollection args)
        //{
        //}
    }
}