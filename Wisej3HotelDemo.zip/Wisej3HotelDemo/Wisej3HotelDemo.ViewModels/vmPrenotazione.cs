﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wisej3HotelDemo.ViewModels
{
    public class vmPrenotazione:  Passero.Framework.ViewModel<Wisej3HotelDemo.Models.Prenotazione >
    {

        public Models.Prenotazione  GetPrenotazione(int IdPrenotazione)
        {
            string sql = $"SELECT * FROM {Passero.Framework.DapperHelper.Utilities.GetTableName(this.ModelType)}" +
                  $" WHERE IdPrenotazione = @IdPrenotazione";
            Dapper.DynamicParameters parameters = new Dapper.DynamicParameters();
            parameters.Add("IdPrenotazione", IdPrenotazione);
            var result = this.GetItem(sql, parameters);

            return result.Value;

        }
    }
}
