﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wisej3HotelDemo.ViewModels
{
    public class vmCalendarioCamere : Passero.Framework.ViewModel<Wisej3HotelDemo.Models.CalendarioCamere>
    {

        public IList<Models.CalendarioCamere> GetCamerePrenotazione(int idPrenotazione)
        {
            string sql = $"SELECT * FROM {Passero.Framework.DapperHelper.Utilities.GetTableName(this.ModelType)}" +
                  $" WHERE IdPrenotazione = @IdPrenotazione";
            var parameters = new { IdPrenotazione = idPrenotazione };
            var result = this.GetItems(sql, parameters);

            return result.Value;

        }


        public IList<Models.CalendarioCamere> GetPrenotazioniCamerePerData(DateTime dataInizio, DateTime dataFine)
        {
            string sql = $"SELECT * FROM {Passero.Framework.DapperHelper.Utilities.GetTableName(this.ModelType)}" +
                  $" WHERE data >= @dataInizio and data <= @dataFine";

            var parameters = new { dataInizio = dataInizio.Date, dataFine = dataFine.Date };
            var result = this.GetItems(sql, parameters);

            return result.Value;

        }

        public IList<Models.CalendarioCamere> GetPrenotazioniCameraPerData(string idCamera, DateTime dataInizio, DateTime dataFine)
        {
            string sql = $"SELECT * FROM {Passero.Framework.DapperHelper.Utilities.GetTableName(this.ModelType)}" +
                  $" WHERE IdCamera=@IdCamera AND data >= @dataInizio AND data <= @dataFine";

            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("IdCamera", idCamera);
            parameters.Add("DataInizio", dataInizio.Date, System.Data.DbType.DateTime );
            parameters.Add("DataFine", dataFine.Date, System.Data.DbType.DateTime );
            //var parameters = new { IdCamera= idCamera, dataInizio = dataInizio, dataFine = dataFine };
            var result = this.GetItems(sql, parameters);
            string rsql= this.ResolvedSQLQuery(sql, parameters);
            return result.Value;

        }

        public IList<Models.CalendarioCamere> GetPrenotazioniCameraPerData(string idCamera)
        {
            string sql = $"SELECT * FROM {Passero.Framework.DapperHelper.Utilities.GetTableName(this.ModelType)}" +
                  $" WHERE IdCamera=@IdCamera";

            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("IdCamera", idCamera);
            
            //var parameters = new { IdCamera= idCamera, dataInizio = dataInizio, dataFine = dataFine };
            var result = this.GetItems(sql, parameters);

            return result.Value;

        }
    }
}
