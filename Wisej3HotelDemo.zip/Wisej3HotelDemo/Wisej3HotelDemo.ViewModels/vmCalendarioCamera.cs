﻿
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wisej3HotelDemo.Models;   

namespace Wisej3HotelDemo.ViewModels
{
    public class vmCalendarioCamera : Passero.Framework.ViewModel<Wisej3HotelDemo.Models.PrenotazioneCamera >
    {

        public IList<Models .PrenotazioneCamera> GetCamerePrenotazione(int idPrenotazione)
        {
          string sql = $"SELECT * FROM {Passero.Framework.DapperHelper .Utilities .GetTableName(this.ModelType )}" +
                $" WHERE IdPrenotazione = @IdPrenotazione";
          var parameters = new { IdPrenotazione = idPrenotazione };
          var result = this.GetItems(sql, parameters);

          return result.Value;

        }


        public IList<Models.PrenotazioneCamera> GetPrenotazioniCamerePerData(DateTime dataInizio, DateTime dataFine)
        {
            string sql = $"SELECT * FROM {Passero.Framework.DapperHelper.Utilities.GetTableName(this.ModelType)}" +
                  $" WHERE dataInizio >= @dataInizio and dataFine <= @dataFine";
          
            var parameters = new { dataInizio = dataInizio.Date , dataFine = dataFine.Date };  
            var result = this.GetItems(sql, parameters);

            return result.Value;

        }

        public IList<Models.PrenotazioneCamera> GetPrenotazioniCameraPerData(string idCamera, DateTime dataInizio, DateTime dataFine)
        {
            string sql = $"SELECT * FROM {Passero.Framework.DapperHelper.Utilities.GetTableName(this.ModelType)}" +
                  $" WHERE IdCamera=@IdCamera AND dataInizio >= @dataInizio AND dataFine <= @dataFine";

            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("IdCamera", idCamera);
            parameters.Add("DataInizio", dataInizio.Date );
            parameters.Add("DataFine", dataFine.Date );
            //var parameters = new { IdCamera= idCamera, dataInizio = dataInizio, dataFine = dataFine };
            var result = this.GetItems(sql, parameters);

            return result.Value;

        }
    }
}
