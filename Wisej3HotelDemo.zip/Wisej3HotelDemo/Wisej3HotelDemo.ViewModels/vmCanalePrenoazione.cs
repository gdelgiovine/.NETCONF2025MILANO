﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wisej3HotelDemo.ViewModels
{
    public class vmCanalePrenotazione: Passero.Framework.ViewModel<Wisej3HotelDemo.Models.CanalePrenotazione >
    {
    }
    
}
