﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace Wisej3HotelDemo.ViewModels
{
    public class vmCamera : Passero.Framework.ViewModel<Wisej3HotelDemo.Models.Camera>
    {

        public IEnumerable<Models.Camera>  GetCamera(string IdCamera)
        {
            string sql = $"SELECT * FROM {Passero.Framework.DapperHelper.Utilities.GetTableName(this.ModelType)}" +
                  $" WHERE IdCamera = @IdCamera";
            Dapper.DynamicParameters parameters = new Dapper.DynamicParameters();
            parameters.Add("IdCamera", IdCamera );  
            var result = this.GetItems(sql, parameters);
            return result.Value;


        }

       
        
    }
}
