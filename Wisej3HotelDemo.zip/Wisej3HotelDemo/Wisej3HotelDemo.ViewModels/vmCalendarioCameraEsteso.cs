﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wisej3HotelDemo.ViewModels
{
    public class vmCalendarioCameraEsteso : Passero.Framework.ViewModel<Wisej3HotelDemo.Models.CalendarioCamereEsteso >
    {

        public IList<Models.CalendarioCamereEsteso> GetCamerePrenotazione(int idPrenotazione)
        {
            //string sql = $"SELECT * FROM {Passero.Framework.DapperHelper.Utilities.GetTableName(this.ModelType)}" +
            string _sql = $"{this.sql} " +
            $" WHERE IdPrenotazione = @IdPrenotazione";
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("IdPrenotazione", idPrenotazione);
            //var parameters = new { IdPrenotazione = idPrenotazione };
            var result = this.GetItems(_sql, parameters);

            return result.Value;

        }


        public IList<Models.CalendarioCamereEsteso> GetPrenotazioniCamerePerData(DateTime dataInizio, DateTime dataFine)
        {
            //string sql = $"SELECT * FROM {Passero.Framework.DapperHelper.Utilities.GetTableName(this.ModelType)}" +
            string _sql = $"{this.sql} " +
            $" WHERE data >= @dataInizio and data <= @dataFine ";// and v.IdCamera='CAM001'";// and CheckInGiorno=1";

            DynamicParameters parameters = new DynamicParameters();
            //var parameters = new { dataInizio = dataInizio.Date, dataFine = dataFine.Date };
            parameters.Add("dataInizio", dataInizio.Date);
            parameters.Add("dataFine", dataFine.Date);
            string x = this.ResolvedSQLQuery (_sql, parameters); 
            var result = this.GetItems(_sql, parameters);

            return result.Value;

        }

        public IList<Models.CalendarioCamereEsteso> GetPrenotazioniCameraPerData(string idCamera, DateTime dataInizio, DateTime dataFine)
        {
            //string sql = $"SELECT * FROM {Passero.Framework.DapperHelper.Utilities.GetTableName(this.ModelType)}" +
            string _sql= $"{this.sql} " + 
                  $" WHERE IdCamera=@IdCamera AND data >= @dataInizio AND data <= @dataFine ";

            DynamicParameters parameters = new DynamicParameters();

            parameters.Add("IdCamera", idCamera);
            parameters.Add("DataInizio", dataInizio.Date);
            parameters.Add("DataFine", dataFine.Date);
            //var parameters = new { IdCamera= idCamera, dataInizio = dataInizio, dataFine = dataFine };
            var result = this.GetItems(_sql, parameters);

            return result.Value;

        }



        string sql = @"
SELECT
    v.IdCamera,
    v.Data,
    v.OccupataDa,
    v.CheckInGiorno,
    v.CheckOutGiorno,
    v.EventiGiorno,
    v.IdPrenotazioneCheckIn,
    v.IdPrenotazioneCheckOut,
    v.IdPrenotazioneOccupanti,

    p.IdCliente,
    p.IdCanale,
    p.DataPrenotazione,
    cp.Nome  AS CanaliPrenotazioni_Nome,
    cp.Sigla AS CanaliPrenotazione_Sigla,
    cp.Icona AS CanaliPrenotazioni_Icona,
    c.Nome   AS Clienti_Nome,
    c.Cognome AS Clienti_Cognome,

    p.DataInizio AS Prenotazione_DataInizio,
    p.DataFine   AS Prenotazione_DataFine,

    -- Date esposte (sempre da PrenotazioniCamere se c'è soggiorno)
    d.DataCheckIn,
    d.DataCheckOut,

    -- Pernottamenti = differenza tra DataCheckOut e DataCheckIn
    CASE
        WHEN d.DataCheckIn IS NOT NULL AND d.DataCheckOut IS NOT NULL
             THEN DATEDIFF(DAY, d.DataCheckIn, d.DataCheckOut)  -- intervallo semiaperto [in, out)
        ELSE NULL
    END AS Pernottamenti

FROM dbo.vCalendarioCamere AS v

-- Seleziona il segmento rilevante di PrenotazioniCamere
OUTER APPLY (
    SELECT TOP (1) pc.*
    FROM dbo.PrenotazioniCamere AS pc
    WHERE pc.IdCamera = v.IdCamera
      AND pc.IdPrenotazione = COALESCE(v.IdPrenotazioneOccupanti,
                                       v.IdPrenotazioneCheckIn,
                                       v.IdPrenotazioneCheckOut)
      AND (
            (v.Data >= pc.DataInizio AND v.Data < pc.DataFine)     -- giorno coperto
         OR (v.CheckInGiorno = 0 AND v.CheckOutGiorno = 1 AND v.Data = pc.DataFine) -- checkout-day
      )
    ORDER BY
        CASE WHEN (v.Data >= pc.DataInizio AND v.Data < pc.DataFine) THEN 0 ELSE 1 END,
        pc.DataInizio DESC
) AS pc_sel

-- Normalizza le date esposte (eventuale cast a date)
OUTER APPLY (
    SELECT
        CONVERT(date, pc_sel.DataInizio) AS DataCheckIn,
        CONVERT(date, pc_sel.DataFine)   AS DataCheckOut
) AS d

-- Join a Prenotazioni/Anagrafiche
LEFT JOIN dbo.Prenotazioni AS p
       ON p.IdPrenotazione = ISNULL(pc_sel.IdPrenotazione,
                                    COALESCE(v.IdPrenotazioneOccupanti,
                                             v.IdPrenotazioneCheckIn,
                                             v.IdPrenotazioneCheckOut))
LEFT JOIN dbo.Clienti AS c
       ON c.IdCliente = p.IdCliente
LEFT JOIN dbo.CanaliPrenotazioni AS cp
       ON cp.IdCanale = p.IdCanale
";

    }
}
