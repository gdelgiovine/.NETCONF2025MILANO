﻿using Wisej3HotelDemo.ViewModels;
using Passero.Framework;
using Passero.Framework.Controls;
using System;
using System.Data;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Wisej.Hybrid;

using Wisej.Web;

namespace Wisej3HotelDemo.Views
{
    public partial class vCamera  : Form
    {

        public Passero.Framework.ConfigurationManager ConfigurationManager = new Passero.Framework.ConfigurationManager();
        private vmCamera  vmCamera = new vmCamera();  
        
        //private IDbConnection  DBConnectionHotelDemo;
        private System.Data.SqlClient.SqlConnection DBConnectionHotelDemo;
        public vCamera()
        {
            InitializeComponent();
        }

        public void Init()
        {
            this.DBConnectionHotelDemo = (System.Data.SqlClient.SqlConnection)this.ConfigurationManager.DBConnections["HotelDemo"];

            vmCamera.Init(DBConnectionHotelDemo );
            vmCamera.DataBindingMode = Passero.Framework.DataBindingMode.BindingSource;
            vmCamera.BindingSource = this.bsCamera ;

            this.dataNavigator1.ViewModels["Camera"] = new Passero.Framework.Controls.DataNavigatorViewModel(this.vmCamera,"Camera");
            this.dataNavigator1.SetActiveViewModel("Camera");
            this.dataNavigator1.ManageNavigation = true;
            this.dataNavigator1.ManageChanges = true;
            this.dataNavigator1.SetLanguage(Application.CurrentCulture .Name );
            this.dataNavigator1.Init(false);
        }

        public void ApriSchedaCamera(string IDCamera)
        {
            if (string.IsNullOrEmpty(IDCamera)) return;
            this.vmCamera.GetCamera(IDCamera);
            
            
            
        }   


        private void QBE_Camere()
        {
            QBEForm<Models.Camera> QBE = new QBEForm<Models.Camera>(this.DBConnectionHotelDemo,this);
            QBE.QBEResultMode = QBEResultMode.MultipleRowsSQLQuery;
            QBE.QBEModelPropertiesMapping.Add(nameof(Models.Camera.IdCamera), nameof(Models.Camera.IdCamera));
            QBE.SetTargetViewModel(this.vmCamera,() =>this.dataNavigator1.Init(true));
            QBE.ShowQBE();
        }
        private void vCamera_Load(object sender, EventArgs e)
        {
            this.Init();
        }

        private void dataNavigator1_eFind()
        {
            this.QBE_Camere();
        }



        private void CapturePhoto()
        {
            Passero.Framework.Controls.CameraForm cameraForm = new Passero.Framework.Controls.CameraForm();
            cameraForm.ApplicationTempPath = Path.GetTempPath();
            cameraForm.WindowState = FormWindowState.Maximized; 
            cameraForm.ShowDialog();
            if (cameraForm.CameraImage != null)
            {
                this.pictureBox1.Image = cameraForm.CameraImage;
            }


            //if (Wisej.Hybrid.Device.Valid)
            //{
            //    System.Drawing.Image result = null;


            //    result = Device.Media.CapturePhoto(800, 600);
            //    //result = Device.Media.PickPhoto(800, 600);



            //        this.pictureBox1.Image = result;

            //}
            //else
            //{
            //    Passero.Framework.Controls.CameraForm cameraForm = new Passero.Framework.Controls.CameraForm();
            //    cameraForm.ApplicationTempPath = Path.GetTempPath();
            //    cameraForm.ShowDialog();
            //    if (cameraForm.CameraImage != null)
            //    {
            //        this.pictureBox1.Image = cameraForm.CameraImage;
            //    }
            //}


        }

        private void btnPhoto_Click(object sender, EventArgs e)
        {
            CapturePhoto();
        }
    }


   
}
