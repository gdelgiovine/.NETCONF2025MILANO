﻿namespace Wisej3HotelDemo.Views
{
    partial class vCamera
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej.NET Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(vCamera));
            Wisej.Web.RequiredValidationRule requiredValidationRule1 = new Wisej.Web.RequiredValidationRule();
            this.txtClamera_Id = new Wisej.Web.TextBox();
            this.bsCamera = new Wisej.Web.BindingSource(this.components);
            this.txtCamera_Nome = new Wisej.Web.TextBox();
            this.txtCamera_Indirizzo = new Wisej.Web.TextBox();
            this.txtCamera_Telefono = new Wisej.Web.TextBox();
            this.txtCamera_Descrizione = new Wisej.Web.TextBox();
            this.cmbCamera_TipoCamera = new Wisej.Web.ComboBox();
            this.flowLayoutPanel1 = new Wisej.Web.FlowLayoutPanel();
            this.btnPhoto = new Wisej.Web.Button();
            this.pictureBox1 = new Wisej.Web.PictureBox();
            this.validation1 = new Wisej.Web.Validation(this.components);
            this.btnScanImage = new Wisej.Web.Button();
            this.dataNavigator1 = new Passero.Framework.Controls.DataNavigator();
            ((System.ComponentModel.ISupportInitialize)(this.bsCamera)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtClamera_Id
            // 
            this.txtClamera_Id.DataBindings.Add(new Wisej.Web.Binding("Text", this.bsCamera, "IdCamera", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.txtClamera_Id.Focusable = false;
            resources.ApplyResources(this.txtClamera_Id, "txtClamera_Id");
            this.txtClamera_Id.Name = "txtClamera_Id";
            // 
            // bsCamera
            // 
            this.bsCamera.DataSource = typeof(Wisej3HotelDemo.Models.Camera);
            // 
            // txtCamera_Nome
            // 
            this.txtCamera_Nome.DataBindings.Add(new Wisej.Web.Binding("Text", this.bsCamera, "Nome", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.flowLayoutPanel1.SetFillWeight(this.txtCamera_Nome, 40);
            resources.ApplyResources(this.txtCamera_Nome, "txtCamera_Nome");
            this.txtCamera_Nome.Name = "txtCamera_Nome";
            // 
            // txtCamera_Indirizzo
            // 
            this.txtCamera_Indirizzo.DataBindings.Add(new Wisej.Web.Binding("Text", this.bsCamera, "Indirizzo", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.flowLayoutPanel1.SetFillWeight(this.txtCamera_Indirizzo, 40);
            this.flowLayoutPanel1.SetFlowBreak(this.txtCamera_Indirizzo, true);
            resources.ApplyResources(this.txtCamera_Indirizzo, "txtCamera_Indirizzo");
            this.txtCamera_Indirizzo.Name = "txtCamera_Indirizzo";
            // 
            // txtCamera_Telefono
            // 
            this.txtCamera_Telefono.DataBindings.Add(new Wisej.Web.Binding("Text", this.bsCamera, "Telefono", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.flowLayoutPanel1.SetFillWeight(this.txtCamera_Telefono, 50);
            this.flowLayoutPanel1.SetFlowBreak(this.txtCamera_Telefono, true);
            resources.ApplyResources(this.txtCamera_Telefono, "txtCamera_Telefono");
            this.txtCamera_Telefono.Name = "txtCamera_Telefono";
            this.validation1.SetValidationRules(this.txtCamera_Telefono, new Wisej.Web.ValidationRule[] {
            ((Wisej.Web.ValidationRule)(requiredValidationRule1))});
            // 
            // txtCamera_Descrizione
            // 
            this.txtCamera_Descrizione.DataBindings.Add(new Wisej.Web.Binding("Text", this.bsCamera, "Descrizione", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.flowLayoutPanel1.SetFillWeight(this.txtCamera_Descrizione, 100);
            this.flowLayoutPanel1.SetFlowBreak(this.txtCamera_Descrizione, true);
            resources.ApplyResources(this.txtCamera_Descrizione, "txtCamera_Descrizione");
            this.txtCamera_Descrizione.Name = "txtCamera_Descrizione";
            // 
            // cmbCamera_TipoCamera
            // 
            this.cmbCamera_TipoCamera.DataBindings.Add(new Wisej.Web.Binding("Text", this.bsCamera, "TipoCamera", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.cmbCamera_TipoCamera.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.flowLayoutPanel1.SetFillWeight(this.cmbCamera_TipoCamera, 50);
            this.cmbCamera_TipoCamera.Items.AddRange(new object[] {
            resources.GetString("cmbCamera_TipoCamera.Items"),
            resources.GetString("cmbCamera_TipoCamera.Items1"),
            resources.GetString("cmbCamera_TipoCamera.Items2"),
            resources.GetString("cmbCamera_TipoCamera.Items3"),
            resources.GetString("cmbCamera_TipoCamera.Items4")});
            resources.ApplyResources(this.cmbCamera_TipoCamera, "cmbCamera_TipoCamera");
            this.cmbCamera_TipoCamera.Name = "cmbCamera_TipoCamera";
            // 
            // flowLayoutPanel1
            // 
            resources.ApplyResources(this.flowLayoutPanel1, "flowLayoutPanel1");
            this.flowLayoutPanel1.Controls.Add(this.txtClamera_Id);
            this.flowLayoutPanel1.Controls.Add(this.txtCamera_Nome);
            this.flowLayoutPanel1.Controls.Add(this.txtCamera_Indirizzo);
            this.flowLayoutPanel1.Controls.Add(this.cmbCamera_TipoCamera);
            this.flowLayoutPanel1.Controls.Add(this.txtCamera_Telefono);
            this.flowLayoutPanel1.Controls.Add(this.txtCamera_Descrizione);
            this.flowLayoutPanel1.Controls.Add(this.btnPhoto);
            this.flowLayoutPanel1.Controls.Add(this.pictureBox1);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            // 
            // btnPhoto
            // 
            resources.ApplyResources(this.btnPhoto, "btnPhoto");
            this.btnPhoto.Name = "btnPhoto";
            this.btnPhoto.Click += new System.EventHandler(this.btnPhoto_Click);
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            // 
            // btnScanImage
            // 
            resources.ApplyResources(this.btnScanImage, "btnScanImage");
            this.btnScanImage.Name = "btnScanImage";
            // 
            // dataNavigator1
            // 
            resources.ApplyResources(this.dataNavigator1, "dataNavigator1");
            this.dataNavigator1.FKeyEnabled = true;
            this.dataNavigator1.Name = "dataNavigator1";
            this.dataNavigator1.eFind += new Passero.Framework.Controls.DataNavigator.eFindEventHandler(this.dataNavigator1_eFind);
            // 
            // vCamera
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.dataNavigator1);
            this.Controls.Add(this.btnScanImage);
            this.Name = "vCamera";
            this.Load += new System.EventHandler(this.vCamera_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bsCamera)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Passero.Framework.Controls.DataNavigator dataNavigator1;
        private Wisej.Web.TextBox txtClamera_Id;
        private Wisej.Web.TextBox txtCamera_Nome;
        private Wisej.Web.TextBox txtCamera_Indirizzo;
        private Wisej.Web.TextBox txtCamera_Telefono;
        private Wisej.Web.BindingSource bsCamera;
        private Wisej.Web.TextBox txtCamera_Descrizione;
        private Wisej.Web.ComboBox cmbCamera_TipoCamera;
        private Wisej.Web.FlowLayoutPanel flowLayoutPanel1;
        private Wisej.Web.Validation validation1;
        private Wisej.Web.Button btnScanImage;
        private Wisej.Web.Button btnPhoto;
        private Wisej.Web.PictureBox pictureBox1;
    }
}