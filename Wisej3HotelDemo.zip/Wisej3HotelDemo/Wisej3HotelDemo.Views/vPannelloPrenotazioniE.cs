﻿using FastDeepCloner;
using Wisej3HotelDemo.Controls;
using Wisej3HotelDemo.Models;
using Wisej3HotelDemo.ViewModels;
using Microsoft.Ajax.Utilities;
using Passero.Framework.Controls;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using Wisej.Web;
using static System.Net.WebRequestMethods;
using static Wisej.Web.Shape;

namespace Wisej3HotelDemo.Views
{
    public partial class vPannelloPrenotazioniE : Form
    {

        public Passero.Framework.ConfigurationManager ConfigurationManager = new Passero.Framework.ConfigurationManager();
        private vmPrenotazione vmPrenotazione = new vmPrenotazione();
        private vmCalendarioCamera vmPrenotazioneCamera = new vmCalendarioCamera();
        private vmCliente vmCliente = new vmCliente();
        private vmCanalePrenotazione vmCanalePrenotazione = new vmCanalePrenotazione();
        //private vmCalendarioCamere vmCalendarioCamere = new vmCalendarioCamere();
        private vmCalendarioCameraEsteso  vmCalendarioCamere = new vmCalendarioCameraEsteso();

        private vmCamera vmCamera = new vmCamera();
        private IDbConnection DBConnectionHotelDemo;
        private IList<Models.Cliente> ElencoClienti = new List<Models.Cliente>();
        private IList<Models.CanalePrenotazione> ElencoCanaliPrenotazione = new List<Models.CanalePrenotazione>();
        private IList<Models.Camera> ElencoCamere = new List<Models.Camera>();
        private int giornigriglia = 365; // Numero di giorni da visualizzare nella griglia   
        private int giornivisibili = 30; // Numero di giorni visibili nella griglia
        private Font MobileFont;
        public vPannelloPrenotazioniE()
        {
            InitializeComponent();
            
        }


        private void Init()
        {
          
            this.DBConnectionHotelDemo = this.ConfigurationManager.DBConnections["HotelDemo"];
            this.vmPrenotazioneCamera.Init (this.DBConnectionHotelDemo);
            this.vmCamera .Init(this.DBConnectionHotelDemo);    
            this.vmCalendarioCamere.Init(this.DBConnectionHotelDemo);
            //Passero.Framework.ControlScaler.Scaler scaler = new Passero.Framework.ControlScaler.Scaler(this);
            //scaler.ProportionalScaleToContainer();
            //if (Application.Browser.Device == "Mobile")
            //{
                
            //    this.MobileFont = new Font(this.Font.FontFamily, 6, FontStyle.Regular);
            //    this.Font = this.MobileFont;
            //    this.dgv_Date.Font = MobileFont;
            //    this.dgv_Prenotazioni.Font = MobileFont;
            //    this.dateTimePicker1.Font = MobileFont;
            //    this.label1.Font = MobileFont;

            //}
            //else
            //{
                
            //}
            //Sincronizza le grigle
            this.dgv_Date.Call("bindToGrid", this.dgv_Prenotazioni , true);
            
            this.dgv_Prenotazioni.ColumnHeadersVisible = false;
            dateTimePicker1 .Value = new DateTime(2025, 8, 14);
            
            this.ConfiguraGrigliaPrenotazioni(giornigriglia, giornivisibili , this.dateTimePicker1.Value);
            CaricaGrigliaPrenotazioniFAST(this.dateTimePicker1.Value);
            //CaricaGrigliaPrenotazioni(this.dateTimePicker1.Value);
            flowLayoutPanel1_Resize(null, null);    
        }


        
        private void ConfiguraGrigliaPrenotazioni(int giorni, int giornivisibili, DateTime dataInizio)
        {
            this.dgv_Prenotazioni.Columns.Clear();
            this.dgv_Prenotazioni.SelectionMode = DataGridViewSelectionMode.NoSelection;
            //this.dgv_Prenotazioni.Focusable  = false;
            this.dgv_Prenotazioni.ReadOnly = true;

           



            DataGridViewColumn dgvc_IdCamera = new Wisej.Web.DataGridViewTextBoxColumn();
            
            dgvc_IdCamera.Name = "dgvc_IdCamera";
            dgvc_IdCamera.HeaderText = "Camera";
            dgvc_IdCamera.Frozen = true;
            dgvc_IdCamera.Width = 200; ;
            dgvc_IdCamera.ReadOnly = true;
            dgvc_IdCamera.SortMode = DataGridViewColumnSortMode.NotSortable;
            dgvc_IdCamera.Resizable = DataGridViewTriState.True  ;

            if (Application.Browser.Device != "Desktop")
            {
                
            }


            this.dgv_Prenotazioni.Columns.Add(dgvc_IdCamera);
            

            // Creazione delle colonne per i giorni 
            for (int i = 0; i < giorni; i++)
            {
                DateTime da = dataInizio.AddDays(i);
                bool visibile = true;   
                //string giorno = da.ToString("dd<br/>MMM<br/>ddd");
                string giorno = $"<b>{da.Day:00}</b><br/>" +
                    $"{Passero.Framework.StringHelper.CapitalizeFirstLetter(da.ToString("MMM"))}<br/>" +
                    $"{Passero.Framework.StringHelper.CapitalizeFirstLetter(da.ToString("ddd"))}";
                if (giornivisibili > 0 && i >= giornivisibili)
                {
                   visibile = false;
                }
                int columnIndex = 0;
                int LarghezzaColonna = 50;
                string nameColonnaO = $"dgvc_Giorno_{i}_O";
                // Colonna CheckOut per il giorno
                columnIndex = this.dgv_Prenotazioni.Columns.Add(new Wisej.Web.DataGridViewTextBoxColumn()
                {
                    Name = $"dgvc_Giorno_{i}_O",
                    AllowHtml = true,
                    HeaderText = $"{giorno}_O",
                    Visible = visibile,
                    ReadOnly = true,
                    SortMode = DataGridViewColumnSortMode.NotSortable,
                    Width = LarghezzaColonna,   
                    Tag = da
                }
                );
                this.dgv_Prenotazioni.Columns[columnIndex].DefaultCellStyle.CssStyle = "border-right:0px;";// cursor: not-allowed; opacity: 0.6;";
              


                // Colonna CheckIn per il giorno
                string nameColonnaI = $"dgvc_Giorno_{i}_I";  
                columnIndex = this.dgv_Prenotazioni.Columns.Add(new Wisej.Web.DataGridViewTextBoxColumn()
               
                {
                    Name = $"dgvc_Giorno_{i}_I",
                    AllowHtml = true,
                    HeaderText = $"{giorno}_I",
                    Visible = visibile,
                    ReadOnly = true,
                    SortMode = DataGridViewColumnSortMode.NotSortable,
                    Width = LarghezzaColonna,
                    
                    Tag = da
                }
                );

                this.dgv_Prenotazioni.Columns[nameColonnaI].DefaultCellStyle.CssStyle = "border-Left: 0px;";// cursor: not-allowed; opacity: 0.6;";
             
                // Colonna Data per la griglia con le date di prenotazione

                columnIndex = this.dgv_Date.Columns.Add(new Wisej.Web.DataGridViewTextBoxColumn()
                {
                    Name = $"dgvc_Giorno_{i}",
                    AllowHtml = true,
                    HeaderText = $"{giorno}",
                    Visible = visibile,
                    ReadOnly = true,
                    SortMode = DataGridViewColumnSortMode.NotSortable,
                    Width = LarghezzaColonna*2,
                   
                    Tag = da
                }
                );
        

            }
            AggiornaIntestazioneGrigliaPrenotazioni(giorni, giornivisibili, dataInizio);

            this.dgv_Date.Columns[0].Width = this.dgv_Prenotazioni.Columns[0].Width-1 ; // Allinea la larghezza della prima colonna delle date con quella della griglia delle prenotazioni
            // creazione delle righe per le camere  
            IList<Models.Camera> camere = this.vmCamera.GetAllItems ().Value ;
            int rowIndex = 0;
            int rowGroupIndex = 1;
            if (camere != null && camere.Count > 0)
            {
                // Ordina le camere per TipoCamera
                var camereOrdinate = camere.OrderBy(c => c.TipoCamera).ToList();
                string tipoCameraPrecedente = string.Empty; 
                foreach (Models.Camera camera in camereOrdinate)
                {
                    
                    if (tipoCameraPrecedente != camera.TipoCamera)
                    {
                        // Aggiungi una riga vuota per il tipo di camera
                        rowIndex = this.dgv_Prenotazioni.Rows.Add();
                        this.dgv_Prenotazioni.Rows[rowIndex].Cells["dgvc_IdCamera"].Value = $"{camera.TipoCamera}";
                        this.dgv_Prenotazioni.Rows[rowIndex].DefaultCellStyle.BackColor = System.Drawing.Color.Honeydew  ;
                        this.dgv_Prenotazioni.Rows[rowIndex].DefaultCellStyle.ForeColor = System.Drawing.Color.DarkOliveGreen;
                        this.dgv_Prenotazioni.Rows[rowIndex].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                        rowGroupIndex = 1;
                    }
                    // Aggiungi una nuova riga e ottieni l'indice
                    rowIndex = this.dgv_Prenotazioni.Rows.Add();
                    
                    // Valorizza la colonna della camera
                    this.dgv_Prenotazioni.Rows[rowIndex].Cells["dgvc_IdCamera"].Value = camera.Nome ?? string.Empty;
                    // Memorizza l'IdCamera nel Tag della riga per riferimento futuro
                    this.dgv_Prenotazioni.Rows[rowIndex].Tag = camera.IdCamera;
                    CtlCamera ctlCamera = new CtlCamera();
                    ctlCamera.Cell = this.dgv_Prenotazioni.Rows[rowIndex].Cells["dgvc_IdCamera"];
                    ctlCamera.InnerControl.Text = camera.Nome ?? string.Empty; 
                    ctlCamera.BorderStyle = BorderStyle.None;
                    ctlCamera.Camera = camera;
                    ctlCamera.Dock = DockStyle.Fill;
                    ctlCamera.UpdateCell();

                    this.dgv_Prenotazioni.Rows[rowIndex].Cells["dgvc_IdCamera"].Control = ctlCamera;
                    // Se la riga è pari imposta il colore di sfondo grigio
                    if (rowGroupIndex % 2 == 0)
                    {
                        this.dgv_Prenotazioni.Rows[rowIndex].DefaultCellStyle.BackColor = this.btnOggi .BackColor;
                        ctlCamera.InnerControl .BackColor = this.btnOggi.BackColor; 
                    }
                    else
                    {
                        this.dgv_Prenotazioni.Rows[rowIndex].DefaultCellStyle.BackColor = System.Drawing.Color.White;
                        ctlCamera.InnerControl.BackColor = System.Drawing.Color.White;
                    }
                    tipoCameraPrecedente = camera.TipoCamera; // Aggiorna il tipo di camera precedente
                    rowGroupIndex++; // Incrementa l'indice del gruppo di righe 
                }
            }

            
        }
        
        
        private void AggiornaIntestazioneGrigliaDate(int giorni, int giornivisibili, DateTime dataInizio)
        {

            this.dgv_Date.Columns[0].Width =this.dgv_Prenotazioni .Columns[0].Width-1;    
            
            for (int i = 0; i < giorni; i++)
            {
                DateTime data = dataInizio.AddDays(i);
                bool visibile = true;
                //string giorno = da.ToString("dd<br/>MMM<br/>ddd");
                string giorno = $"{data.Day:00}<br/>" +
                    $"{Passero.Framework.StringHelper.CapitalizeFirstLetter(data.ToString("MMM"))}<br/>" +
                    $"{Passero.Framework.StringHelper.CapitalizeFirstLetter(data.ToString("ddd"))}";


                if (giornivisibili > 0 && i + 1 >= giornivisibili)
                {
                    visibile = false;
                }


                // Imposta l'intestazione della colonna nella griglia delle date
                DataGridViewColumn column = this.dgv_Date.Columns[i + 1];
                {
                   
                    column.HeaderText = $"{giorno}";
                    column.Visible = visibile;
                    column.Tag = data;
                    

                    if (data.DayOfWeek == DayOfWeek.Sunday | data.DayOfWeek == DayOfWeek.Saturday)
                    {
                        column.HeaderStyle.BackColor = System.Drawing.Color.MistyRose;
                        column.HeaderStyle.ForeColor = System.Drawing.Color.Red;
                    }
                    else
                    {
                        column.HeaderStyle.BackColor = System.Drawing.Color.White;
                        column.HeaderStyle.ForeColor = System.Drawing.Color.Black;
                    }

                    if (data.Date == DateTime.Now.Date)
                    {
                        column.HeaderStyle.BackColor = System.Drawing.Color.LightBlue;
                        column.HeaderStyle.ForeColor = System.Drawing.Color.DarkBlue;
                    }
                }

            }

          

        }

        private void AggiornaIntestazioneGrigliaPrenotazioni(int giorni, int giornivisibili, DateTime dataInizio)
        {

            AggiornaIntestazioneGrigliaDate (giorni, giornivisibili, dataInizio);

            for (int i = 0; i < giorni; i++)
            {
                DateTime data = dataInizio.AddDays(i);
                bool visibile = true;
                //string giorno = da.ToString("dd<br/>MMM<br/>ddd");
                string giorno = $"{data.Day:00}<br/>" +
                    $"{Passero.Framework.StringHelper.CapitalizeFirstLetter(data.ToString("MMM"))}<br/>" +
                    $"{Passero.Framework.StringHelper.CapitalizeFirstLetter(data.ToString("ddd"))}";


                if (giornivisibili > 0 && i + 1 >= giornivisibili*2-1)
                {
                    visibile = false;
                }


                // Imposta l'intestazione della colonna nella griglia delle date
                DataGridViewColumn column = this.dgv_Prenotazioni.Columns[i + 1];
                column.Visible = visibile;

            }

            CaricaGrigliaPrenotazioniFAST(this.dateTimePicker1.Value);

        }



        private CtlElementoCalendario CreaSpanControlE(CalendarCellType CellType)
        {
            CtlElementoCalendario  ctl = new CtlElementoCalendario();
            //TextBox ctl= this.textBox1 .Clone() as TextBox;
            ctl.SuspendLayout();
            ctl.CellType = CellType;
            ctl.InnerControl.Top = 0;
            ctl.InnerControl.Left = 0;
            ctl.InnerControl.ReadOnly = false;
            ctl.InnerControl.Focusable = false;
            ctl.InnerControl.TabStop   = false;
            ctl.BackColor = System.Drawing.Color.Transparent;
            ctl.InnerControl.BackColor = System.Drawing.Color.Aquamarine;
            ctl.BorderStyle = BorderStyle.None;
            ctl.CssStyle = "border-top-left-radius: 30px;border-top-right-radius: 10px;border-bottom-right-radius: 30px;border-bottom-left-radius: 10px;border-left:0px solid transparent;";
            ctl.InnerControl.CssStyle = ctl.CssStyle;
            ctl.InnerControl.BorderStyle = BorderStyle.None;
            ctl.InnerControl.Visible = true;
            ctl.ResumeLayout(true);
            return ctl;
        }

        private void AggiornaCelleRigaFAST(DataGridViewRow row, IList<Models.CalendarioCamereEsteso > prenotazioni, DateTime dataInizio)
        {
            // **OTTIMIZZAZIONE: Pool di controlli riutilizzabili**
            var controlliRiutilizzabili = new Dictionary<string, TextBox >();
            var controlliRiutilizzabiliE = new Dictionary<string, CtlElementoCalendario>();

            // Raccogli i controlli esistenti che possono essere riutilizzati
            foreach (DataGridViewCell cell in row.Cells)
            {
                if (cell.ColumnIndex > 0 && cell.Control is TextBox  ctlEsistente)
                {
                    string nomeColonna = cell.OwningColumn.Name;
                    controlliRiutilizzabili[nomeColonna] = ctlEsistente;
                    cell.Control = null; // Rimuovi temporaneamente
                }

                if (cell.ColumnIndex > 0)
                {
                        cell.Style.ColSpan = 1;
                }
            }

            foreach (var prenotazione in prenotazioni)
            {
                if (prenotazione.Data == default(DateTime))
                    continue;

                DateTime? dataPrenotazione = prenotazione.Data;
                // recuperare il tipo EventoGiornata per la prenotazione    

                
                EventiGiornata eventiGiornata    = new EventiGiornata();
                eventiGiornata = this.OttieniEventiGiornata(prenotazione);  

                string NomeColonnaI = $"dgvc_Giorno_{(dataPrenotazione.Value - dataInizio.Date).Days}_I";
                string NomeColonnaO = $"dgvc_Giorno_{(dataPrenotazione.Value - dataInizio.Date).Days}_O";

                //Gestione della colonna CheckOUT
                if (row.Cells[NomeColonnaO] != null)
                {
                    row[NomeColonnaO].Tag = prenotazione;
                    
                    bool Covered = Passero.Framework.ControlsUtilities.DataGridViewIsCellCoveredByColSpan(row[NomeColonnaO]);
                    if (Covered == false)
                    {
                        int SpanO = 0;
                        
                        CtlElementoCalendario  SpanControlO = RicicloControlliE(NomeColonnaO, ref controlliRiutilizzabiliE);
                        if (SpanControlO == null)
                        {
                            SpanControlO = CreaSpanControlE( CalendarCellType.CheckOut);
                        }
                        SpanControlO.SetStandardCSSStyle();
                        SpanControlO .ElementoCalendario = prenotazione;  
                        SpanControlO.Cell = row[NomeColonnaO];
                        SpanControlO.InnerControl .Text = $"{prenotazione.Clienti_NomeBreve}";
                        SpanControlO.InnerControl.ToolTipText = $"Prenotazione {prenotazione.Clienti_NomeCompleto}"; 
                        if (eventiGiornata == EventiGiornata.CheckOut )
                        {
                            SpanControlO.Text = $"{prenotazione.IdPrenotazioneCheckOut}";
                        }

                        if (eventiGiornata == EventiGiornata.CheckInCheckOut )
                        {
                            if (prenotazione .CheckOutGiorno == 1)
                            {
                                SpanControlO.Text = $"{prenotazione.IdPrenotazioneCheckOut}";
                                SpanO = prenotazione.Pernottamenti ;
                            }
                        }
                        if (SpanControlO.Text.IsNullOrWhiteSpace() )
                            SpanControlO .Visible = false; // Nascondi il controllo se non c'è testo    

                        if (eventiGiornata == EventiGiornata.FullDay)
                        {
                            
                        }


                        row[NomeColonnaO].Control = SpanControlO;
                        SpanControlO.UpdateCell();

                    }
                    
                }

                //Gestione della colonna CheckIN    
                if (row.Cells[NomeColonnaI] != null)
                {
                    row[NomeColonnaI].Tag = prenotazione;
                    bool Covered = Passero.Framework.ControlsUtilities.DataGridViewIsCellCoveredByColSpan(row[NomeColonnaI]);
                    string NomeColonna = NomeColonnaI;
                    if (Covered == false)
                    {
                        
                        CtlElementoCalendario SpanControlI = RicicloControlliE(NomeColonnaI, ref controlliRiutilizzabiliE);
                        if (SpanControlI == null)
                        {
                            SpanControlI = CreaSpanControlE(CalendarCellType.CheckIn);
                        }

                        SpanControlI.ElementoCalendario = prenotazione;
                        SpanControlI.Cell = row[NomeColonnaI];
                        SpanControlI.InnerControl.Text = $"{prenotazione.Clienti_NomeBreve}";
                        SpanControlI.InnerControl.ToolTipText = $"Prenotazione {prenotazione.Clienti_NomeCompleto}";
                        int SpanI = 0;
                        if (eventiGiornata == EventiGiornata.CheckIn)
                        {
                            SpanControlI.SetStandardCSSStyle();
                            SpanControlI.Text = $"{prenotazione.IdPrenotazioneCheckIn}";
                            SpanI = prenotazione.Pernottamenti * 2;
                            row[NomeColonna].Control = SpanControlI;
                            row[NomeColonna].Style.ColSpan = SpanI;
                            if (SpanControlI.Text.IsNullOrWhiteSpace())
                                SpanControlI.Visible = false; // Nascondi il controllo se non c'è testo    
                            SpanControlI.UpdateCell();

                        }
                        if (eventiGiornata == EventiGiornata.CheckInCheckOut)
                        {
                            SpanControlI.SetStandardCSSStyle ();
                            SpanControlI.Text = $"{prenotazione.IdPrenotazioneCheckIn}";
                            SpanI = prenotazione.Pernottamenti * 2;
                            row[NomeColonna].Control = SpanControlI;
                            row[NomeColonna].Style.ColSpan = SpanI;
                            if (SpanControlI.Text.IsNullOrWhiteSpace())
                                SpanControlI.Visible = false; // Nascondi il controllo se non c'è testo    
                            SpanControlI.UpdateCell();

                        }
                        if (eventiGiornata == EventiGiornata.FullDay)
                        {
                            SpanControlI.Text = $"{prenotazione.IdPrenotazioneOccupanti}";
                            NomeColonna = NomeColonnaO; // Cambia il nome della colonna per il FullDay  
                            int residuo = prenotazione.DataCheckIn.HasValue
                                ? (prenotazione.DataCheckOut.Value.Date - prenotazione.Data.Date).Days
                                : 0;
                            if (Passero.Framework.ControlsUtilities.DataGridViewIsCellCoveredByColSpan(row[NomeColonnaI]))
                                SpanI = 0;

                            SpanI = residuo * 2 + 1;

                            // Assegna controllo e imposta proprietà
                            row[NomeColonna].Control = SpanControlI;
                            // cambia il bordo destro della cella
                            SpanControlI.SetFullDayCSSStyle();
                            SpanControlI.Cell = row[NomeColonna];
                            if (SpanI > 0)
                            {
                                row[NomeColonna].Style.ColSpan = SpanI;
                            }

                            // Nascondi se necessario
                            if (SpanControlI.Text.IsNullOrWhiteSpace())
                                SpanControlI.Visible = false;

                            // Aggiorna dimensioni
                            SpanControlI.UpdateCell();

                        }

                        



                    }
                }

            }

            // **PULIZIA**: Disponi i controlli non utilizzati
            foreach (var ctlNonUtilizzato in controlliRiutilizzabili.Values)
            {
                ctlNonUtilizzato.Dispose();
            }
        }
              

        private CtlElementoCalendario RicicloControlliE(string Nome, ref Dictionary<string, CtlElementoCalendario > controlliRiutilizzabili)
        {
            // **RIUTILIZZO**: Usa controllo esistente se disponibile
            CtlElementoCalendario  ctl;
            if (controlliRiutilizzabili.ContainsKey(Nome))
            {
                ctl = controlliRiutilizzabili[Nome];
                controlliRiutilizzabili.Remove(Nome);
            }
            else
            {
                ctl = null;// CreaSpanControl();
            }
            return ctl;
        }
        private EventiGiornata OttieniEventiGiornata(CalendarioCamereEsteso prenotazione)
        {
            EventiGiornata stato = new EventiGiornata();
            stato = EventiGiornata.Free;
            if (prenotazione.OccupataDa == 1)
            {
                if (prenotazione.EventiGiorno == 1)
                {
                    if (prenotazione.CheckInGiorno == 1)
                        stato = EventiGiornata.CheckIn;
                    if (prenotazione.CheckOutGiorno == 1)
                        stato = EventiGiornata.CheckOut;
                }

                if (prenotazione.EventiGiorno == 2)
                {
                    if (prenotazione.CheckInGiorno == 1 && prenotazione.CheckOutGiorno == 1)
                        stato = EventiGiornata.CheckInCheckOut;


                }
                if (prenotazione.EventiGiorno == 0)
                {
                    stato = EventiGiornata.FullDay;
                }
                return stato;
            }

            if (prenotazione.OccupataDa == 0)
            {
                if (prenotazione.CheckOutGiorno == 1)
                    stato = EventiGiornata.CheckOut;
            }

            return stato;
        }
        private void CaricaGrigliaPrenotazioniFAST(DateTime dataInizio)
        {
            // **OTTIMIZZAZIONE 1: Sospendere il rendering della griglia**
            //this.SuspendLayout ();  
            this.dgv_Prenotazioni.SuspendLayout();

            try
            {
                // **OTTIMIZZAZIONE 2: Single query per tutte le camere**
                var tutteLePrenotazioni = this.vmCalendarioCamere.GetPrenotazioniCamerePerData(
                    dataInizio,
                    dataInizio.AddDays(giornigriglia));

                // Raggruppa le prenotazioni per IdCamera per accesso più veloce
              

                var prenotazioniRaggruppatePerCamera = tutteLePrenotazioni?
                   .GroupBy(p => p.IdCamera)
                   .ToDictionary(g => g.Key, g => g.ToList())
                   ?? new Dictionary<string, List<Models.CalendarioCamereEsteso >>();

                foreach (DataGridViewRow row in this.dgv_Prenotazioni.Rows)
                {
                    if (row.Tag is string idCamera)
                    {
                        // **OTTIMIZZAZIONE 3: Riutilizzo dei controlli esistenti**
                        CancellaRigaPrenotazioniCameraFAST(row);

                       
                        var prenotazionicamera = prenotazioniRaggruppatePerCamera.ContainsKey(idCamera)
                            ? prenotazioniRaggruppatePerCamera[idCamera]
                            : new List<Models.CalendarioCamereEsteso>();

                        // **OTTIMIZZAZIONE 4: Batch update delle celle**
                        AggiornaCelleRigaFAST(row, prenotazionicamera, dataInizio);
                    }
                    else
                    {
                        // gestisce le righe con il tipo camera
                    }
                }
            }
            finally
            {
                // **OTTIMIZZAZIONE 5: Ripristina il rendering**
                this.dgv_Prenotazioni.ResumeLayout(true);
                //this.ResumeLayout(true);    
            }
        }



        private void CancellaRigaPrenotazioniCameraFAST(DataGridViewRow row)
        {
            foreach (DataGridViewCell cell in row.Cells)
            {
                // Cancella il contenuto della cella
                if (cell.ColumnIndex > 0 && cell.OwningColumn.Tag is DateTime dataColonna)
                {
                    
                    if (cell.Value != null)
                    {
                        cell.Value = null;
                    }
                    if (cell.Control != null)
                    {
                        // Rimuovi il controllo associato alla cella
                        cell.Control.Dispose();
                        cell.Control = null;
                    }
                }
            }
        }

        private void CancellaColonneRiga(DataGridViewRow row,int colonnaIniziale, int colonnaFinale)
        {
            // Validazione dei parametri
            if (colonnaIniziale < 0 || colonnaIniziale >= this.dgv_Prenotazioni.Columns.Count)
                return;

            if (colonnaFinale < 0 || colonnaFinale >= this.dgv_Prenotazioni.Columns.Count)
                return;

            if (colonnaIniziale > colonnaFinale)
                return;

                // Cicla attraverso l'intervallo di colonne specificato
                for (int columnIndex = colonnaIniziale; columnIndex <= colonnaFinale; columnIndex++)
                {
                    row.Cells[columnIndex].Value = null;
                }
            
        }

        private void vPannelloPrenotazioni_Load(object sender, EventArgs e)
        {
            this.Init();
        }

        private void dateTimePicker1_ToolClick(object sender, ToolClickEventArgs e)
        {
            if (e.Tool.Name == "Avanti")
            {
                DateTime dataInizio = this.dateTimePicker1.Value;
                dataInizio = dataInizio.AddDays(1);
                this.dateTimePicker1.Value = dataInizio;
                this.AggiornaIntestazioneGrigliaPrenotazioni (giornigriglia ,giornivisibili, dataInizio);
            }
            else if (e.Tool.Name == "Indietro")
            {
                DateTime dataInizio = this.dateTimePicker1.Value;
                dataInizio = dataInizio.AddDays(-1);
                this.dateTimePicker1.Value = dataInizio;
                this.AggiornaIntestazioneGrigliaPrenotazioni(giornigriglia,giornivisibili, dataInizio);
            }
        }

        private void btn7Giorni_Click(object sender, EventArgs e)
        {
            this.giornivisibili = 7;
            AggiornaIntestazioneGrigliaPrenotazioni(giornigriglia, giornivisibili, this.dateTimePicker1.Value);
        }

        private void btn15Giorni_Click(object sender, EventArgs e)
        {
            this.giornivisibili = 15;
            AggiornaIntestazioneGrigliaPrenotazioni(giornigriglia, giornivisibili, this.dateTimePicker1.Value);

        }

        private void btn30Giorni_Click(object sender, EventArgs e)
        {
            this.giornivisibili = 30;
            AggiornaIntestazioneGrigliaPrenotazioni(giornigriglia, giornivisibili, this.dateTimePicker1.Value);

        }

        private void btnOggi_Click(object sender, EventArgs e)
        {
            this.dateTimePicker1.Value = DateTime.Now;
            AggiornaIntestazioneGrigliaPrenotazioni(giornigriglia, giornivisibili, this.dateTimePicker1.Value);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.giornivisibili = this.giornigriglia ;
            AggiornaIntestazioneGrigliaPrenotazioni(giornigriglia, giornivisibili, this.dateTimePicker1.Value);

        }

        private void dgv_Prenotazioni_CellToolClick(object sender, DataGridViewToolClickEventArgs e)
        {

            DataGridViewCell cell = this.dgv_Prenotazioni[e.ColumnIndex, e.RowIndex];
            Models.CalendarioCamereEsteso  calendarioCamera  = (Models.CalendarioCamereEsteso )cell.Tag;
          
            
            if (e.Tool.Name.Equals("CtlCamera_Info", StringComparison.InvariantCultureIgnoreCase))
            {
                CtlCamera ctlCamera = cell.Control as CtlCamera;
                string FormName=$"vCamera_{ctlCamera.Camera .IdCamera}";
                Views.vCamera vCamera = Passero.Framework.ControlsUtilities.FormExist<Views.vCamera>(FormName);
                if (vCamera is null)
                {
                    vCamera = new vCamera();
                    vCamera.Name = FormName;  
                    vCamera.ConfigurationManager = this.ConfigurationManager;
                    vCamera.MdiParent = MdiParent;
                    vCamera.Text ="Scheda Camera " + ctlCamera.Camera.Nome;   
                    
                }
                vCamera.Init();
                vCamera.ApriSchedaCamera(ctlCamera.Camera.IdCamera);
                vCamera .Show();


            }

            if (e.Tool.Name.Equals("CtlCamera_NewReservation", StringComparison.InvariantCultureIgnoreCase))
            {
                CtlCamera ctlCamera = cell.Control as CtlCamera;
                string FormName = $"vCamera_NewReservation_{ctlCamera.Camera.IdCamera}";
                Views.vPrenotazione vPrenotazione = Passero.Framework.ControlsUtilities.FormExist<Views.vPrenotazione>("vPrenotazione");
                if (vPrenotazione is null)
                {
                    vPrenotazione = new vPrenotazione();
                    vPrenotazione.Name =FormName;
                    vPrenotazione.ConfigurationManager = this.ConfigurationManager;
                    vPrenotazione.MdiParent = MdiParent;
                    vPrenotazione.Text = "Nuova Prenotazione Camera " + ctlCamera.Camera.Nome;  
                    
                }

                vPrenotazione.Init();
                vPrenotazione.Show();
                vPrenotazione.CreaNuovaPrenotazioneCamera(ctlCamera.Camera.IdCamera);
                

            }


            if (e.Tool.Name.Equals("CtlElementoCalendario_Info", StringComparison.InvariantCultureIgnoreCase))
            {
                CtlElementoCalendario ctl = cell.Control as CtlElementoCalendario;
                EventiGiornata evento = OttieniEventiGiornata(ctl.ElementoCalendario);
                string FormName = $"vPrenotazione_{ctl.ElementoCalendario.IdPrenotazioneCheckIn }";
                Views.vPrenotazione vPrenotazione = Passero.Framework.ControlsUtilities.FormExist <Views.vPrenotazione>("vPrenotazione");
                
                if (vPrenotazione is null)
                {
                    vPrenotazione = new vPrenotazione();
                    vPrenotazione.ConfigurationManager = this.ConfigurationManager;
                    vPrenotazione.MdiParent = MdiParent;
                    vPrenotazione.Name = FormName;
                    vPrenotazione.ConfigurationManager = this.ConfigurationManager;
                    vPrenotazione.MdiParent = MdiParent;
                    vPrenotazione.Text = "Prenotazione N." + ctl.ElementoCalendario.IdPrenotazioneCheckIn;  
                    vPrenotazione.Init();
                }

                

                switch (ctl.CellType)
                {
                    case CalendarCellType.CheckIn:
                        
                        vPrenotazione.ApriSchedaPrenotazione(ctl.ElementoCalendario.IdPrenotazioneCheckIn);
                        vPrenotazione.Show();
                        vPrenotazione.Activate();
                        vPrenotazione.BringToFront();
                        break;
                    case CalendarCellType.CheckOut:
                        vPrenotazione.ApriSchedaPrenotazione(ctl.ElementoCalendario.IdPrenotazioneCheckOut);
                        vPrenotazione.Show();
                        vPrenotazione.Activate();
                        vPrenotazione.BringToFront();
                        break;

                    case CalendarCellType.Free:
                        break;
                    default:
                        break;
                }



            }

           
        }

        private void dgv_Prenotazioni_EndResize(object sender, EventArgs e)
        {
            this.dgv_Date.Width = this.dgv_Prenotazioni.Width; 
            
        }

        private void dgv_Date_ColumnWidthChanged(object sender, DataGridViewColumnEventArgs e)
        {
            this.dgv_Date.Columns[0].Width = this.dgv_Prenotazioni.Columns[0].Width - 1; // Allinea la larghezza della prima colonna delle date con quella della griglia delle prenotazioni
        }

        private void dgv_Prenotazioni_Scroll(object sender, ScrollEventArgs e)
        {
            if (e.ScrollOrientation == ScrollOrientation.HorizontalScroll)
            {

                // Sincronizza lo scroll orizzontale della griglia delle date con quella delle prenotazioni
                
            }
        }

        private void dgv_Prenotazioni_ToolClick(object sender, ToolClickEventArgs e)
        {

            MessageBox.Show("CCCC");


        }

        private void dgv_Prenotazioni_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show(this.dgv_Prenotazioni[e.ColumnIndex, e.RowIndex].OwningColumn.Name);
        }

        private void dgv_Prenotazioni_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //if (e.ColumnIndex > 1)
            //{

            //    e.CellStyle.CssStyle = "border-width:0px!important";
            //}
        }

        private void vPannelloPrenotazioniE_Resize(object sender, EventArgs e)
        {
            flowLayoutPanel1_Resize(null, null);
        }

        private void flowLayoutPanel1_Resize(object sender, EventArgs e)
        {
            this.dgv_Prenotazioni.Top = this.flowLayoutPanel1.Height + 1;
            this.dgv_Prenotazioni.Left = 0;
            this.dgv_Prenotazioni.Width = this.ClientSize.Width;
            this.dgv_Prenotazioni.Height = this.ClientSize.Height - this.dgv_Prenotazioni.Top;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Eval("goFullScreen()");
        }

        private void button3_Click(object sender, EventArgs e)
        {


            // Scala al 80% con limiti personalizzati
            // Riduce del 50% rispetto alle dimensioni originali
            GridFontScaler.ScaleGridFromOriginal(this.dgv_Prenotazioni, -50);
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.trackBar1.Value = 0;
            //GridFontScaler.ResetToOriginalDimensions(this.dgv_Prenotazioni);
        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            int value = this.trackBar1.Value;   
            GridFontScaler.ScaleGridFromOriginal(this.dgv_Prenotazioni, value );
        }
    }

}
