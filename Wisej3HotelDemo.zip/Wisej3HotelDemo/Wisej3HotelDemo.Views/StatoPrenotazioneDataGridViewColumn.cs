using System;
using Wisej.Web;

namespace Wisej3HotelDemo.Views
{
    public class StatoPrenotazioneDataGridViewColumn : DataGridViewColumn
    {
        public StatoPrenotazioneDataGridViewColumn() : base(new StatoPrenotazioneDataGridViewCell())
        {
            this.ReadOnly = false; // Cambiato per permettere l'interazione
        }

        public override DataGridViewCell CellTemplate
        {
            get { return base.CellTemplate; }
            set
            {
                if (value != null && !value.GetType().IsAssignableFrom(typeof(StatoPrenotazioneDataGridViewCell)))
                {
                    throw new InvalidCastException("Must be a StatoPrenotazioneDataGridViewCell");
                }
                base.CellTemplate = value;
            }
        }

        protected override void OnDataGridViewChanged()
        {
            base.OnDataGridViewChanged();

            if (DataGridView != null)
            {
                // Sottoscrivi agli eventi di ridimensionamento
                DataGridView.ColumnWidthChanged += OnColumnWidthChanged;
                DataGridView.RowHeightChanged += OnRowHeightChanged;
                DataGridView.Scroll += OnDataGridViewScroll;
            }
        }

        private void OnColumnWidthChanged(object sender, DataGridViewColumnEventArgs e)
        {
            if (e.Column == this)
            {
                // Aggiorna la posizione di tutte le celle di questa colonna
                foreach (DataGridViewRow row in DataGridView.Rows)
                {
                    if (row.Cells[Index] is StatoPrenotazioneDataGridViewCell cell)
                    {
                        cell.OnColumnWidthChanged();
                    }
                }
            }
        }

        private void OnRowHeightChanged(object sender, DataGridViewRowEventArgs e)
        {
            // Aggiorna la posizione della cella in questa riga
            if (e.Row.Cells[Index] is StatoPrenotazioneDataGridViewCell cell)
            {
                cell.OnRowHeightChanged();
            }
        }

        private void OnDataGridViewScroll(object sender, ScrollEventArgs e)
        {
            // Aggiorna la posizione di tutte le celle visibili quando si fa scroll
            foreach (DataGridViewRow row in DataGridView.Rows)
            {
                if (row.Cells[Index] is StatoPrenotazioneDataGridViewCell cell)
                {
                    cell.OnColumnWidthChanged(); // Riusa questo metodo per aggiornare la posizione
                }
            }
        }
    }
}