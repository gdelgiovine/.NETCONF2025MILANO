﻿
using System;
using System.Drawing;
using Wisej.Web;

namespace Wisej3HotelDemo.Controls
{

  

    public partial class CtlCamera : Wisej.Web.UserControl
    {
        // Eventi pubblici esposti dallo UserControl
        public event EventHandler<ToolClickEventArgs> CheckOutToolClick;
        public event EventHandler<ToolClickEventArgs> CheckInToolClick;
        
        
       
        DataGridViewCell _cell; 
        public DataGridViewCell Cell {
            get { return _cell; }
            set 
            {
                _cell = value;
                if (_cell != null)
                {
                   
                    //this.Width  = _cell.Width  * (_cell.Style.ColSpan * 2);
                    //this.Height = _cell.Height;
                }
            } 
        
        }

        public Models.Camera Camera { get; set; }
        public CtlCamera()
        {
            InitializeComponent();
            this.Top = 0;
            this.Left = 0;
            



        }

        public void UpdateCell()
        {
            if (_cell == null) return;
            // Aggiorna le dimensioni del controllo in base alla cella
            this.Width = _cell.Width * (_cell.Style.ColSpan );
            this.Height = _cell.Height;
            this.InnerControl.Top = 0;
            this.InnerControl.Left = 0;
            this.InnerControl.Height = this.ClientSize.Height ;  
            this.InnerControl.Width = this.ClientSize.Width;    
        }

        private void CtlPrenotazione_Resize(object sender, EventArgs e)
        {
            
        }

        /// <summary>
        /// Trova il DataGridView genitore che contiene questo controllo
        /// </summary>
        private DataGridView GetParentDataGridView()
        {
            Control parent = this.Parent;
            while (parent != null)
            {
                if (parent is DataGridView dgv)
                    return dgv;
                parent = parent.Parent;
            }
            return null;
        }

        /// <summary>
        /// Trova la cella che contiene questo controllo
        /// </summary>
        private (int rowIndex, int columnIndex) GetCellPosition()
        {
            var dataGridView = GetParentDataGridView();
            if (dataGridView == null) return (-1, -1);

            // Cerca la cella che contiene questo controllo
            for (int row = 0; row < dataGridView.Rows.Count; row++)
            {
                for (int col = 0; col < dataGridView.Columns.Count; col++)
                {
                    if (dataGridView.Rows[row].Cells[col].Control == this)
                    {
                        return (row, col);
                    }
                }
            }
            return (-1, -1);
        }

        /// <summary>
        /// Convoglia l'evento ToolClick al CellToolClick del DataGridView
        /// </summary>
        private void ForwardToolClickToDataGridView(ToolClickEventArgs e, string Name)
        {
            var dataGridView = GetParentDataGridView();
            if (dataGridView == null) return;

            var (rowIndex, columnIndex) = GetCellPosition();
            if (rowIndex < 0 || columnIndex < 0) return;

            // Modifica il nome del tool per identificare il pannello di origine
            var originalToolName = e.Tool.Name;
            e.Tool.Name = $"{Name}_{originalToolName}";

            try
            {
                // Crea l'evento CellToolClick con i parametri corretti
                var cellToolClickEventArgs = new DataGridViewToolClickEventArgs(e.Tool, columnIndex, rowIndex);

                // Usa la reflection per invocare l'evento CellToolClick del DataGridView
                var eventInfo = typeof(DataGridView).GetEvent("CellToolClick");
                if (eventInfo != null)
                {
                    // Cerca il metodo OnCellToolClick protetto - correzione dei BindingFlags
                    var onCellToolClickMethod = typeof(DataGridView).GetMethod("OnCellToolClick",
                        System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic,
                        null,
                        new Type[] { typeof(DataGridViewToolClickEventArgs) },
                        null);

                    if (onCellToolClickMethod != null)
                    {
                        onCellToolClickMethod.Invoke(dataGridView, new object[] { cellToolClickEventArgs });
                    }
                    else
                    {
                        // Fallback: cerca il field dell'evento e invocalo direttamente
                        var eventField = typeof(DataGridView).GetField("CellToolClick",
                            System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);

                        if (eventField != null)
                        {
                            var eventDelegate = (System.MulticastDelegate)eventField.GetValue(dataGridView);
                            eventDelegate?.DynamicInvoke(dataGridView, cellToolClickEventArgs);
                        }
                        else
                        {
                            // Ultimo tentativo: cerca tutti i metodi che contengono "CellToolClick"
                            var methods = typeof(DataGridView).GetMethods(
                                System.Reflection.BindingFlags.Instance |
                                System.Reflection.BindingFlags.NonPublic |
                                System.Reflection.BindingFlags.Public);

                            foreach (var method in methods)
                            {
                                if (method.Name.Contains("CellToolClick") && method.GetParameters().Length == 1)
                                {
                                    var paramType = method.GetParameters()[0].ParameterType;
                                    if (paramType.IsAssignableFrom(typeof(DataGridViewToolClickEventArgs)))
                                    {
                                        method.Invoke(dataGridView, new object[] { cellToolClickEventArgs });
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Log dell'errore se necessario
                System.Diagnostics.Debug.WriteLine($"Errore nel forwarding dell'evento ToolClick: {ex.Message}");
            }
            finally
            {
                // Ripristina il nome originale del tool
                e.Tool.Name = originalToolName;
            }
        }

        // Metodi per scatenare gli eventi pubblici ToolClick   
      

        protected virtual void OnCheckInToolClick(ToolClickEventArgs e)
        {
            CheckInToolClick?.Invoke(this, e);
            ForwardToolClickToDataGridView(e, this.Name );
        }

        

      

     

        private void InnerControl_ToolClick(object sender, ToolClickEventArgs e)
        {
            OnCheckInToolClick(e);
        }
    }
}