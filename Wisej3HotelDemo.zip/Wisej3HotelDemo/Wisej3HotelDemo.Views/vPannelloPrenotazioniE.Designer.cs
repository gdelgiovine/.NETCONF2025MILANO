﻿namespace Wisej3HotelDemo.Views
{
    partial class vPannelloPrenotazioniE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej.NET Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle1 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle2 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.ComponentTool componentTool1 = new Wisej.Web.ComponentTool();
            Wisej.Web.ComponentTool componentTool2 = new Wisej.Web.ComponentTool();
            Wisej.Web.ComponentTool componentTool3 = new Wisej.Web.ComponentTool();
            Wisej.Web.ComponentTool componentTool4 = new Wisej.Web.ComponentTool();
            this.dgv_Prenotazioni = new Wisej.Web.DataGridView();
            this.dgvc_Data = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgv_Date = new Wisej.Web.DataGridView();
            this.dgvc_Data_Camere = new Wisej.Web.DataGridViewTextBoxColumn();
            this.pnlPiedeGrigliaPrenotazioni = new Wisej.Web.FlowLayoutPanel();
            this.lblLegendaCamere = new Wisej.Web.Label();
            this.label1 = new Wisej.Web.Label();
            this.dateTimePicker1 = new Wisej.Web.DateTimePicker();
            this.btnOggi = new Wisej.Web.Button();
            this.btn7Giorni = new Wisej.Web.Button();
            this.btn15Giorni = new Wisej.Web.Button();
            this.btn30Giorni = new Wisej.Web.Button();
            this.button1 = new Wisej.Web.Button();
            this.flowLayoutPanel1 = new Wisej.Web.FlowLayoutPanel();
            this.button2 = new Wisej.Web.Button();
            this.button3 = new Wisej.Web.Button();
            this.button4 = new Wisej.Web.Button();
            this.trackBar1 = new Wisej.Web.TrackBar();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Prenotazioni)).BeginInit();
            this.dgv_Prenotazioni.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Date)).BeginInit();
            this.pnlPiedeGrigliaPrenotazioni.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_Prenotazioni
            // 
            this.dgv_Prenotazioni.AllowUserToResizeColumns = false;
            this.dgv_Prenotazioni.AllowUserToResizeRows = false;
            this.dgv_Prenotazioni.Anchor = Wisej.Web.AnchorStyles.None;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("@menu", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgv_Prenotazioni.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Prenotazioni.ColumnHeadersHeight = 64;
            this.dgv_Prenotazioni.Columns.AddRange(new Wisej.Web.DataGridViewColumn[] {
            this.dgvc_Data});
            this.dgv_Prenotazioni.Controls.Add(this.dgv_Date);
            this.dgv_Prenotazioni.Controls.Add(this.pnlPiedeGrigliaPrenotazioni);
            this.dgv_Prenotazioni.DefaultRowHeight = 28;
            this.dgv_Prenotazioni.Location = new System.Drawing.Point(5, 39);
            this.dgv_Prenotazioni.Name = "dgv_Prenotazioni";
            this.dgv_Prenotazioni.RowHeadersVisible = false;
            this.dgv_Prenotazioni.RowTemplate.Resizable = Wisej.Web.DataGridViewTriState.False;
            this.dgv_Prenotazioni.SelectionMode = Wisej.Web.DataGridViewSelectionMode.NoSelection;
            this.dgv_Prenotazioni.ShowFocusCell = false;
            this.dgv_Prenotazioni.Size = new System.Drawing.Size(1066, 497);
            this.dgv_Prenotazioni.TabIndex = 0;
            this.dgv_Prenotazioni.CellFormatting += new Wisej.Web.DataGridViewCellFormattingEventHandler(this.dgv_Prenotazioni_CellFormatting);
            this.dgv_Prenotazioni.CellClick += new Wisej.Web.DataGridViewCellEventHandler(this.dgv_Prenotazioni_CellClick);
            this.dgv_Prenotazioni.ToolClick += new Wisej.Web.ToolClickEventHandler(this.dgv_Prenotazioni_ToolClick);
            this.dgv_Prenotazioni.CellToolClick += new Wisej.Web.DataGridViewToolClickEventHandler(this.dgv_Prenotazioni_CellToolClick);
            this.dgv_Prenotazioni.Scroll += new Wisej.Web.ScrollEventHandler(this.dgv_Prenotazioni_Scroll);
            this.dgv_Prenotazioni.EndResize += new System.EventHandler(this.dgv_Prenotazioni_EndResize);
            // 
            // dgvc_Data
            // 
            this.dgvc_Data.Frozen = true;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.MistyRose;
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Red;
            this.dgvc_Data.HeaderStyle = dataGridViewCellStyle2;
            this.dgvc_Data.HeaderText = "Data/Camera";
            this.dgvc_Data.Name = "dgvc_Data";
            componentTool1.ImageSource = "menu-overflow";
            componentTool1.Name = "Servizi";
            componentTool1.ToolTipText = "Informazioni sui Servizi ";
            componentTool2.ImageSource = "table-row-editing";
            componentTool2.Name = "Modifica";
            componentTool2.ToolTipText = "Modifica Scheda Camera";
            this.dgvc_Data.Tools.AddRange(new Wisej.Web.ComponentTool[] {
            componentTool1,
            componentTool2});
            // 
            // dgv_Date
            // 
            this.dgv_Date.AllowUserToResizeColumns = false;
            this.dgv_Date.AllowUserToResizeRows = false;
            this.dgv_Date.ColumnHeadersHeight = 64;
            this.dgv_Date.Columns.AddRange(new Wisej.Web.DataGridViewColumn[] {
            this.dgvc_Data_Camere});
            this.dgv_Date.Dock = Wisej.Web.DockStyle.Top;
            this.dgv_Date.Location = new System.Drawing.Point(0, 0);
            this.dgv_Date.Name = "dgv_Date";
            this.dgv_Date.RowHeadersVisible = false;
            this.dgv_Date.ScrollBars = Wisej.Web.ScrollBars.None;
            this.dgv_Date.Size = new System.Drawing.Size(1064, 66);
            this.dgv_Date.TabIndex = 1;
            this.dgv_Date.ColumnWidthChanged += new Wisej.Web.DataGridViewColumnEventHandler(this.dgv_Date_ColumnWidthChanged);
            // 
            // dgvc_Data_Camere
            // 
            this.dgvc_Data_Camere.Frozen = true;
            this.dgvc_Data_Camere.HeaderText = "Data/Camere";
            this.dgvc_Data_Camere.Name = "dgvc_Data_Camere";
            this.dgvc_Data_Camere.Width = 99;
            // 
            // pnlPiedeGrigliaPrenotazioni
            // 
            this.pnlPiedeGrigliaPrenotazioni.Controls.Add(this.lblLegendaCamere);
            this.pnlPiedeGrigliaPrenotazioni.Dock = Wisej.Web.DockStyle.Bottom;
            this.pnlPiedeGrigliaPrenotazioni.Location = new System.Drawing.Point(0, 468);
            this.pnlPiedeGrigliaPrenotazioni.Name = "pnlPiedeGrigliaPrenotazioni";
            this.pnlPiedeGrigliaPrenotazioni.Size = new System.Drawing.Size(1064, 27);
            this.pnlPiedeGrigliaPrenotazioni.TabIndex = 0;
            // 
            // lblLegendaCamere
            // 
            //this.lblLegendaCamere.Image = global::Wisej3HotelDemo.Views.Properties.Resources.ImagineLegendaCamere;
            this.lblLegendaCamere.Location = new System.Drawing.Point(3, 3);
            this.lblLegendaCamere.Name = "lblLegendaCamere";
            this.lblLegendaCamere.Size = new System.Drawing.Size(1005, 18);
            this.lblLegendaCamere.TabIndex = 1;
            this.lblLegendaCamere.Text = "Legenda Camere";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("default", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label1.Location = new System.Drawing.Point(3, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 32);
            this.label1.TabIndex = 7;
            this.label1.Text = "Planning Prenotazioni";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Anchor = ((Wisej.Web.AnchorStyles)((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Right)));
            this.dateTimePicker1.Focusable = false;
            this.dateTimePicker1.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(245, 3);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.ShowCalendar = false;
            this.dateTimePicker1.Size = new System.Drawing.Size(125, 30);
            this.dateTimePicker1.TabIndex = 1;
            componentTool3.ImageSource = "scrollbar-arrow-left";
            componentTool3.Name = "Indietro";
            componentTool3.Position = Wisej.Web.LeftRightAlignment.Left;
            componentTool4.ImageSource = "scrollbar-arrow-right";
            componentTool4.Name = "Avanti";
            this.dateTimePicker1.Tools.AddRange(new Wisej.Web.ComponentTool[] {
            componentTool3,
            componentTool4});
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            this.dateTimePicker1.ToolClick += new Wisej.Web.ToolClickEventHandler(this.dateTimePicker1_ToolClick);
            // 
            // btnOggi
            // 
            this.btnOggi.Anchor = ((Wisej.Web.AnchorStyles)((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Right)));
            this.btnOggi.Focusable = false;
            this.btnOggi.Location = new System.Drawing.Point(376, 3);
            this.btnOggi.Name = "btnOggi";
            this.btnOggi.Size = new System.Drawing.Size(77, 30);
            this.btnOggi.TabIndex = 2;
            this.btnOggi.TabStop = false;
            this.btnOggi.Text = "Oggi";
            this.btnOggi.Click += new System.EventHandler(this.btnOggi_Click);
            // 
            // btn7Giorni
            // 
            this.btn7Giorni.Anchor = ((Wisej.Web.AnchorStyles)((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Right)));
            this.btn7Giorni.Focusable = false;
            this.btn7Giorni.Location = new System.Drawing.Point(459, 3);
            this.btn7Giorni.Name = "btn7Giorni";
            this.btn7Giorni.Size = new System.Drawing.Size(77, 30);
            this.btn7Giorni.TabIndex = 3;
            this.btn7Giorni.TabStop = false;
            this.btn7Giorni.Text = "7 Giorni";
            this.btn7Giorni.Click += new System.EventHandler(this.btn7Giorni_Click);
            // 
            // btn15Giorni
            // 
            this.btn15Giorni.Anchor = ((Wisej.Web.AnchorStyles)((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Right)));
            this.btn15Giorni.Focusable = false;
            this.btn15Giorni.Location = new System.Drawing.Point(542, 3);
            this.btn15Giorni.Name = "btn15Giorni";
            this.btn15Giorni.Size = new System.Drawing.Size(77, 30);
            this.btn15Giorni.TabIndex = 4;
            this.btn15Giorni.TabStop = false;
            this.btn15Giorni.Text = "15 Giorni";
            this.btn15Giorni.Click += new System.EventHandler(this.btn15Giorni_Click);
            // 
            // btn30Giorni
            // 
            this.btn30Giorni.Anchor = Wisej.Web.AnchorStyles.Top;
            this.btn30Giorni.Focusable = false;
            this.btn30Giorni.Location = new System.Drawing.Point(625, 3);
            this.btn30Giorni.Name = "btn30Giorni";
            this.btn30Giorni.Size = new System.Drawing.Size(77, 30);
            this.btn30Giorni.TabIndex = 5;
            this.btn30Giorni.TabStop = false;
            this.btn30Giorni.Text = "30 Giorni";
            this.btn30Giorni.Click += new System.EventHandler(this.btn30Giorni_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((Wisej.Web.AnchorStyles)((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Right)));
            this.flowLayoutPanel1.SetFlowBreak(this.button1, true);
            this.button1.Focusable = false;
            this.button1.Location = new System.Drawing.Point(791, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(34, 30);
            this.button1.TabIndex = 6;
            this.button1.TabStop = false;
            this.button1.Text = "...";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.Controls.Add(this.label1);
            this.flowLayoutPanel1.Controls.Add(this.dateTimePicker1);
            this.flowLayoutPanel1.Controls.Add(this.btnOggi);
            this.flowLayoutPanel1.Controls.Add(this.btn7Giorni);
            this.flowLayoutPanel1.Controls.Add(this.btn15Giorni);
            this.flowLayoutPanel1.Controls.Add(this.btn30Giorni);
            this.flowLayoutPanel1.Controls.Add(this.button2);
            this.flowLayoutPanel1.Controls.Add(this.button1);
            this.flowLayoutPanel1.Controls.Add(this.button3);
            this.flowLayoutPanel1.Controls.Add(this.button4);
            this.flowLayoutPanel1.Controls.Add(this.trackBar1);
            this.flowLayoutPanel1.Dock = Wisej.Web.DockStyle.Top;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1076, 78);
            this.flowLayoutPanel1.TabIndex = 2;
            this.flowLayoutPanel1.Resize += new System.EventHandler(this.flowLayoutPanel1_Resize);
            // 
            // button2
            // 
            this.button2.Anchor = ((Wisej.Web.AnchorStyles)((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Right)));
            this.button2.Focusable = false;
            this.button2.Location = new System.Drawing.Point(708, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(77, 30);
            this.button2.TabIndex = 8;
            this.button2.TabStop = false;
            this.button2.Text = "Full Screen";
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Anchor = ((Wisej.Web.AnchorStyles)((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Right)));
            this.button3.Focusable = false;
            this.button3.Location = new System.Drawing.Point(3, 41);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(77, 30);
            this.button3.TabIndex = 9;
            this.button3.TabStop = false;
            this.button3.Text = "Full Screen";
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Anchor = ((Wisej.Web.AnchorStyles)((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Right)));
            this.button4.Focusable = false;
            this.button4.Location = new System.Drawing.Point(86, 41);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(77, 30);
            this.button4.TabIndex = 10;
            this.button4.TabStop = false;
            this.button4.Text = "Full Screen";
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(169, 41);
            this.trackBar1.Maximum = 200;
            this.trackBar1.Minimum = -200;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(100, 34);
            this.trackBar1.TabIndex = 11;
            this.trackBar1.Visible = false;
            this.trackBar1.ValueChanged += new System.EventHandler(this.trackBar1_ValueChanged);
            // 
            // vPannelloPrenotazioniE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 19F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1076, 539);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.dgv_Prenotazioni);
            this.Name = "vPannelloPrenotazioniE";
            this.Text = "Pannello Prenotazioni";
            this.Load += new System.EventHandler(this.vPannelloPrenotazioni_Load);
            this.Resize += new System.EventHandler(this.vPannelloPrenotazioniE_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Prenotazioni)).EndInit();
            this.dgv_Prenotazioni.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Date)).EndInit();
            this.pnlPiedeGrigliaPrenotazioni.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Wisej.Web.DataGridView dgv_Prenotazioni;
        private Wisej.Web.DataGridViewTextBoxColumn dgvc_Data;
        private Wisej.Web.DateTimePicker dateTimePicker1;
        private Wisej.Web.Button btnOggi;
        private Wisej.Web.Button btn7Giorni;
        private Wisej.Web.Button btn15Giorni;
        private Wisej.Web.Button btn30Giorni;
        private Wisej.Web.Button button1;
        private Wisej.Web.Label lblLegendaCamere;
        private Wisej.Web.Label label1;
        private Wisej.Web.FlowLayoutPanel pnlPiedeGrigliaPrenotazioni;
        private Wisej.Web.DataGridView dgv_Date;
        private Wisej.Web.DataGridViewTextBoxColumn dgvc_Data_Camere;
        private Wisej.Web.FlowLayoutPanel flowLayoutPanel1;
        private Wisej.Web.Button button2;
        private Wisej.Web.Button button3;
        private Wisej.Web.Button button4;
        private Wisej.Web.TrackBar trackBar1;
    }
}