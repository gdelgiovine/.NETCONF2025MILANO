
using Wisej3HotelDemo.Controls;
using Wisej3HotelDemo.Models;
using Wisej3HotelDemo.Views;

using System;
using System.Drawing;
using Wisej.Web;

namespace Wisej3HotelDemo.Views
{
    public class StatoPrenotazioneDataGridViewCell : DataGridViewCell
    {
  
        private bool _isInitialized = false;

        public override Type EditType => null;
        public override Type ValueType => typeof(object);
        public override object DefaultNewRowValue => null; //StatiGiornata.Free;

        // Propriet� per accedere al controllo ospitato
        public CtlPrenotazione HostedControl
        {
            get
            {
                if (_hostedControl == null)
                {
                    InitializeHostedControl();
                }
                return _hostedControl;
            }
        }

        public StatiGiornata StatoGiornata
        {
            get { return HostedControl.StatoGiornata; }
            set { HostedControl.StatoGiornata = value; }
        }

        public RoomLegends RoomLegend
        {
            get { return HostedControl.RoomLegend; }
            set { HostedControl.RoomLegend = value; }
        }

        public Color Color
        {
            get { return HostedControl.Color; }
            set { HostedControl.Color = value; }
        }

        public PrenotazioneCamera PrenotazioneCamera
        {
            get { return HostedControl.PrenotazioneCamera; }
            set { HostedControl.PrenotazioneCamera = value; }
        }

        private void InitializeHostedControl()
        {
            if (_hostedControl == null)
            {
                _hostedControl = new CtlPrenotazione();
                //_hostedControl.Dock = DockStyle.Fill;
                _hostedControl.Margin = new Padding(0);
                _hostedControl.Visible = false;

                // Aggiungi gestori eventi per l'interazione
                _hostedControl.Click += OnHostedControlClick;
                _hostedControl.MouseEnter += OnHostedControlMouseEnter;
                _hostedControl.MouseLeave += OnHostedControlMouseLeave;
            }
        }

        protected override void OnDataGridViewChanged()
        {
            base.OnDataGridViewChanged();

            if (DataGridView != null && !_isInitialized)
            {
                InitializeInDataGridView();
            }
        }

        private void InitializeInDataGridView()
        {
            if (DataGridView != null && RowIndex >= 0 && ColumnIndex >= 0)
            {
                InitializeHostedControl();

                if (!DataGridView.Controls.Contains(_hostedControl))
                {
                    DataGridView.Controls.Add(_hostedControl);
                }

                _isInitialized = true;
                UpdateControlPosition();
            }
        }



        ////protected override void Paint(Graphics graphics, Rectangle clipBounds, Rectangle cellBounds,
        ////    int rowIndex, DataGridViewElementStates cellState, object value, object formattedValue,
        ////    string errorText, DataGridViewCellStyle cellStyle, DataGridViewAdvancedBorderStyle advancedBorderStyle,
        ////    DataGridViewPaintParts paintParts)
        //{
        //    if (rowIndex < 0 || ColumnIndex < 0)
        //    {
        //        base.Paint(graphics, clipBounds, cellBounds, rowIndex, cellState, value, formattedValue,
        //            errorText, cellStyle, advancedBorderStyle, paintParts);
        //        return;
        //    }

        //    // Aggiorna il valore del controllo
        //    UpdateControlValue(value);

        //    // Assicurati che il controllo sia inizializzato e posizionato correttamente
        //    if (DataGridView != null && _hostedControl != null)
        //    {
        //        if (!DataGridView.Controls.Contains(_hostedControl))
        //        {
        //            DataGridView.Controls.Add(_hostedControl);
        //        }

        //        UpdateControlPosition(cellBounds);
        //        _hostedControl.Visible = true;
        //        _hostedControl.BringToFront();
        //    }

        //    // Pulisce il background della cella
        //    graphics.FillRectangle(new SolidBrush(cellStyle.BackColor), cellBounds);
        //}

        private void UpdateControlValue(object value)
        {
            if (_hostedControl == null) return;

            if (value is StatiGiornata statoGiornata)
            {
                _hostedControl.StatoGiornata = statoGiornata;
            }
            else if (value is PrenotazioneCamera prenotazione)
            {
                _hostedControl.PrenotazioneCamera = prenotazione;
                _hostedControl.StatoGiornata = MappaStatoPrenotazione(prenotazione);
            }
            else if (value is int intValue)
            {
                _hostedControl.StatoPrenotazione = intValue;
            }
        }

        private StatiGiornata MappaStatoPrenotazione(PrenotazioneCamera prenotazione)
        {
            if (prenotazione == null) return StatiGiornata.Free;

            // Implementa la logica di mappatura basata sulle propriet� della prenotazione
            switch (prenotazione.Stato?.ToLowerInvariant())
            {
                case "checkin":
                    return StatiGiornata.CheckIn;
                case "checkout":
                    return StatiGiornata.CheckOut;
                case "fullday":
                case "soggiorno":
                    return StatiGiornata.FullDay;
                default:
                    return StatiGiornata.Free;
            }
        }

        private void UpdateControlPosition(Rectangle? cellBounds = null)
        {
            if (DataGridView == null || _hostedControl == null || RowIndex < 0 || ColumnIndex < 0)
                return;

            return;

            Rectangle bounds;
            bounds = cellBounds.Value;
            //if (cellBounds.HasValue)
            //{
            //    bounds = cellBounds.Value;
            //}
            //else
            //{
            //    // Calcola manualmente i bounds della cella
            //    bounds = CalculateCellBounds();
            //}

            // Posiziona il controllo all'interno della cella con un piccolo margine
            _hostedControl.Location = new Point(bounds.X + 1, bounds.Y + 1);
            _hostedControl.Size = new Size(Math.Max(1, bounds.Width - 2), Math.Max(1, bounds.Height - 2));
        }

        //private Rectangle CalculateCellBounds()
        //{
        //    if (DataGridView == null || RowIndex < 0 || ColumnIndex < 0)
        //        return Rectangle.Empty;

        //    // Calcola la posizione X sommando le larghezze delle colonne precedenti
        //    int x = 0;
        //    for (int i = 0; i < ColumnIndex; i++)
        //    {
        //        if (DataGridView.Columns[i].Visible)
        //        {
        //            x += DataGridView.Columns[i].Width;
        //        }
        //    }

        //    // Calcola la posizione Y sommando le altezze delle righe precedenti
        //    int y = DataGridView.ColumnHeadersHeight;
        //    for (int i = 0; i < RowIndex; i++)
        //    {
        //        if (DataGridView.Rows[i].Visible)
        //        {
        //            y += DataGridView.Rows[i].Height;
        //        }
        //    }

        //    // Ottieni larghezza e altezza della cella corrente
        //    int width = DataGridView.Columns[ColumnIndex].Width;
        //    int height = DataGridView.Rows[RowIndex].Height;

        //    // Per Wisej.Web, usa FirstDisplayedScrollingRowIndex e FirstDisplayedScrollingColumnIndex
        //    if (DataGridView.FirstDisplayedScrollingColumnIndex > 0)
        //    {
        //        for (int i = 0; i < DataGridView.FirstDisplayedScrollingColumnIndex && i < ColumnIndex; i++)
        //        {
        //            if (DataGridView.Columns[i].Visible)
        //            {
        //                x -= DataGridView.Columns[i].Width;
        //            }
        //        }
        //    }

        //    if (DataGridView.FirstDisplayedScrollingRowIndex > 0)
        //    {
        //        for (int i = 0; i < DataGridView.FirstDisplayedScrollingRowIndex && i < RowIndex; i++)
        //        {
        //            if (DataGridView.Rows[i].Visible)
        //            {
        //                y -= DataGridView.Rows[i].Height;
        //            }
        //        }
        //    }

        //    return new Rectangle(x, y, width, height);
        //}

        // Gestori eventi per l'interazione con il controllo
        private void OnHostedControlClick(object sender, EventArgs e)
        {
            if (DataGridView != null && RowIndex >= 0 && ColumnIndex >= 0)
            {
                DataGridView.CurrentCell = this;

                // Scatena un evento personalizzato se necessario
                OnCellClick();
            }
        }

        private void OnHostedControlMouseEnter(object sender, EventArgs e)
        {
            // Gestisci l'hover del controllo
        }

        private void OnHostedControlMouseLeave(object sender, EventArgs e)
        {
            // Gestisci quando il mouse esce dal controllo
        }

        protected virtual void OnCellClick()
        {
            // Override questo metodo per gestire click personalizzati
        }

        // Metodi pubblici per aggiornare la posizione quando la griglia cambia
        public void OnColumnWidthChanged()
        {
            UpdateControlPosition();
        }

        public void OnRowHeightChanged()
        {
            UpdateControlPosition();
        }

        public void OnScrollChanged()
        {
            UpdateControlPosition();
        }

        public override DataGridViewCell Clone()
        {
            var clone = (StatoPrenotazioneDataGridViewCell)base.Clone();
            clone._hostedControl = null;
            clone._isInitialized = false;
            return clone;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && _hostedControl != null)
            {
                if (DataGridView != null && DataGridView.Controls.Contains(_hostedControl))
                {
                    DataGridView.Controls.Remove(_hostedControl);
                }
                _hostedControl.Dispose();
                _hostedControl = null;
            }
            base.Dispose(disposing);
        }

        // Metodi per accedere ai pannelli del controllo ospitato
        public Panel GetCheckInPanel()
        {
            return HostedControl?.Controls["pnlCheckIn"] as Panel;
        }

        public Panel GetCheckOutPanel()
        {
            return HostedControl?.Controls["pnlCheckOut"] as Panel;
        }

        public Panel GetFullDayPanel()
        {
            return HostedControl?.Controls["pnlFullDay"] as Panel;
        }
    }
}