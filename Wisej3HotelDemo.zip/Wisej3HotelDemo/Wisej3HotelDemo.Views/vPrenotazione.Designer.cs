﻿namespace Wisej3HotelDemo.Views
{
    partial class vPrenotazione
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej.NET Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle1 = new Wisej.Web.DataGridViewCellStyle();
            Wisej.Web.DataGridViewCellStyle dataGridViewCellStyle2 = new Wisej.Web.DataGridViewCellStyle();
            this.dataNavigator1 = new Passero.Framework.Controls.DataNavigator();
            this.dtpPrenotazione_DataPrenotazione = new Wisej.Web.DateTimePicker();
            this.bsPrenotazione = new Wisej.Web.BindingSource(this.components);
            this.txtPrenotazione_IdPrenotazione = new Wisej.Web.TextBox();
            this.dtpPrenotazione_DataInizio = new Wisej.Web.DateTimePicker();
            this.dtpPrenotazione_DataFine = new Wisej.Web.DateTimePicker();
            this.cmbPrenotazione_IdCliente = new Wisej.Web.ComboBox();
            this.comboBox1 = new Wisej.Web.ComboBox();
            this.pnlPrenotazione = new Wisej.Web.FlowLayoutPanel();
            this.txtPrenotazione_Descrizione = new Wisej.Web.TextBox();
            this.tabGestionePrenotazione = new Wisej.Web.TabControl();
            this.tabGestionePrenotazione_Prenotazione = new Wisej.Web.TabPage();
            this.dgv_PrenotazioneCamera = new Wisej.Web.DataGridView();
            this.dgvc_IdPrenotazione = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvc_IdCamera = new Wisej.Web.DataGridViewComboBoxColumn();
            this.dgvc_DataInizio = new Wisej.Web.DataGridViewDateTimePickerColumn();
            this.dgvc_DataFine = new Wisej.Web.DataGridViewDateTimePickerColumn();
            this.dgvc_Prenotazione_Stato = new Wisej.Web.DataGridViewTextBoxColumn();
            this.dgvc_Note = new Wisej.Web.DataGridViewTextBoxColumn();
            this.tabGestionePrenotazione_Camere = new Wisej.Web.TabPage();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrenotazione)).BeginInit();
            this.pnlPrenotazione.SuspendLayout();
            this.tabGestionePrenotazione.SuspendLayout();
            this.tabGestionePrenotazione_Prenotazione.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PrenotazioneCamera)).BeginInit();
            this.SuspendLayout();
            // 
            // dataNavigator1
            // 
            this.dataNavigator1.Dock = Wisej.Web.DockStyle.Top;
            this.dataNavigator1.Name = "dataNavigator1";
            this.dataNavigator1.Size = new System.Drawing.Size(851, 70);
            this.dataNavigator1.TabIndex = 0;
            this.dataNavigator1.eBoundCompleted += new Passero.Framework.Controls.DataNavigator.eBoundCompletedEventHandler(this.dataNavigator1_eBoundCompleted);
            this.dataNavigator1.eAddNewRequest += new Passero.Framework.Controls.DataNavigator.eAddNewRequestEventHandler(this.dataNavigator1_eAddNewRequest);
            this.dataNavigator1.eAfterAddNewRequest += new Passero.Framework.Controls.DataNavigator.eAfterAddNewEventHandler(this.dataNavigator1_eAfterAddNewRequest);
            // 
            // dtpPrenotazione_DataPrenotazione
            // 
            this.dtpPrenotazione_DataPrenotazione.DataBindings.Add(new Wisej.Web.Binding("NullableValue", this.bsPrenotazione, "DataPrenotazione", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.dtpPrenotazione_DataPrenotazione.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dtpPrenotazione_DataPrenotazione.LabelText = "Data Prenotazione";
            this.dtpPrenotazione_DataPrenotazione.Location = new System.Drawing.Point(109, 3);
            this.dtpPrenotazione_DataPrenotazione.Name = "dtpPrenotazione_DataPrenotazione";
            this.dtpPrenotazione_DataPrenotazione.Size = new System.Drawing.Size(117, 53);
            this.dtpPrenotazione_DataPrenotazione.TabIndex = 11;
            // 
            // bsPrenotazione
            // 
            this.bsPrenotazione.DataSource = typeof(Wisej3HotelDemo.Models.Prenotazione);
            // 
            // txtPrenotazione_IdPrenotazione
            // 
            this.txtPrenotazione_IdPrenotazione.DataBindings.Add(new Wisej.Web.Binding("Text", this.bsPrenotazione, "IdPrenotazione", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.txtPrenotazione_IdPrenotazione.Focusable = false;
            this.txtPrenotazione_IdPrenotazione.LabelText = "Id Prenotazione";
            this.txtPrenotazione_IdPrenotazione.Location = new System.Drawing.Point(3, 3);
            this.txtPrenotazione_IdPrenotazione.Name = "txtPrenotazione_IdPrenotazione";
            this.txtPrenotazione_IdPrenotazione.ReadOnly = true;
            this.txtPrenotazione_IdPrenotazione.Size = new System.Drawing.Size(100, 53);
            this.txtPrenotazione_IdPrenotazione.TabIndex = 8;
            this.txtPrenotazione_IdPrenotazione.TextChanged += new System.EventHandler(this.txtPrenotazione_IdPrenotazione_TextChanged);
            // 
            // dtpPrenotazione_DataInizio
            // 
            this.dtpPrenotazione_DataInizio.CustomFormat = "dd/MM/yyyy";
            this.dtpPrenotazione_DataInizio.DataBindings.Add(new Wisej.Web.Binding("NullableValue", this.bsPrenotazione, "DataInizio", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.dtpPrenotazione_DataInizio.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dtpPrenotazione_DataInizio.LabelText = "Data Inizio";
            this.dtpPrenotazione_DataInizio.Location = new System.Drawing.Point(604, 3);
            this.dtpPrenotazione_DataInizio.Name = "dtpPrenotazione_DataInizio";
            this.dtpPrenotazione_DataInizio.Size = new System.Drawing.Size(117, 53);
            this.dtpPrenotazione_DataInizio.TabIndex = 16;
            // 
            // dtpPrenotazione_DataFine
            // 
            this.dtpPrenotazione_DataFine.CustomFormat = "dd/MM/yyyy";
            this.dtpPrenotazione_DataFine.DataBindings.Add(new Wisej.Web.Binding("NullableValue", this.bsPrenotazione, "DataFine", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.pnlPrenotazione.SetFlowBreak(this.dtpPrenotazione_DataFine, true);
            this.dtpPrenotazione_DataFine.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dtpPrenotazione_DataFine.LabelText = "Data Fine";
            this.dtpPrenotazione_DataFine.Location = new System.Drawing.Point(727, 3);
            this.dtpPrenotazione_DataFine.Name = "dtpPrenotazione_DataFine";
            this.dtpPrenotazione_DataFine.Size = new System.Drawing.Size(117, 53);
            this.dtpPrenotazione_DataFine.TabIndex = 17;
            // 
            // cmbPrenotazione_IdCliente
            // 
            this.cmbPrenotazione_IdCliente.DataBindings.Add(new Wisej.Web.Binding("SelectedValue", this.bsPrenotazione, "IdCliente", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.cmbPrenotazione_IdCliente.DisplayMember = "NomeCompleto";
            this.cmbPrenotazione_IdCliente.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cmbPrenotazione_IdCliente.LabelText = "Id Cliente";
            this.cmbPrenotazione_IdCliente.Location = new System.Drawing.Point(418, 3);
            this.cmbPrenotazione_IdCliente.MinimumSize = new System.Drawing.Size(150, 0);
            this.cmbPrenotazione_IdCliente.Name = "cmbPrenotazione_IdCliente";
            this.cmbPrenotazione_IdCliente.Size = new System.Drawing.Size(180, 53);
            this.cmbPrenotazione_IdCliente.TabIndex = 18;
            this.cmbPrenotazione_IdCliente.ValueMember = "IdCliente";
            // 
            // comboBox1
            // 
            this.comboBox1.DataBindings.Add(new Wisej.Web.Binding("SelectedValue", this.bsPrenotazione, "IdCanale", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.comboBox1.DisplayMember = "NomeCompleto";
            this.comboBox1.LabelText = "Id Canale";
            this.comboBox1.Location = new System.Drawing.Point(232, 3);
            this.comboBox1.MinimumSize = new System.Drawing.Size(150, 0);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(180, 53);
            this.comboBox1.TabIndex = 19;
            this.comboBox1.ValueMember = "IdCliente";
            // 
            // pnlPrenotazione
            // 
            this.pnlPrenotazione.AutoScroll = true;
            this.pnlPrenotazione.AutoSize = true;
            this.pnlPrenotazione.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pnlPrenotazione.Controls.Add(this.txtPrenotazione_IdPrenotazione);
            this.pnlPrenotazione.Controls.Add(this.dtpPrenotazione_DataPrenotazione);
            this.pnlPrenotazione.Controls.Add(this.comboBox1);
            this.pnlPrenotazione.Controls.Add(this.cmbPrenotazione_IdCliente);
            this.pnlPrenotazione.Controls.Add(this.dtpPrenotazione_DataInizio);
            this.pnlPrenotazione.Controls.Add(this.dtpPrenotazione_DataFine);
            this.pnlPrenotazione.Controls.Add(this.txtPrenotazione_Descrizione);
            this.pnlPrenotazione.Dock = Wisej.Web.DockStyle.Top;
            this.pnlPrenotazione.Location = new System.Drawing.Point(0, 0);
            this.pnlPrenotazione.Name = "pnlPrenotazione";
            this.pnlPrenotazione.Size = new System.Drawing.Size(849, 120);
            this.pnlPrenotazione.TabIndex = 20;
            this.pnlPrenotazione.Resize += new System.EventHandler(this.pnlPrenotazione_Resize);
            // 
            // txtPrenotazione_Descrizione
            // 
            this.txtPrenotazione_Descrizione.DataBindings.Add(new Wisej.Web.Binding("Text", this.bsPrenotazione, "Descrizione", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.pnlPrenotazione.SetFillWeight(this.txtPrenotazione_Descrizione, 100);
            this.pnlPrenotazione.SetFlowBreak(this.txtPrenotazione_Descrizione, true);
            this.txtPrenotazione_Descrizione.Focusable = false;
            this.txtPrenotazione_Descrizione.LabelText = "Descrizione";
            this.txtPrenotazione_Descrizione.Location = new System.Drawing.Point(3, 62);
            this.txtPrenotazione_Descrizione.Name = "txtPrenotazione_Descrizione";
            this.txtPrenotazione_Descrizione.Size = new System.Drawing.Size(841, 53);
            this.txtPrenotazione_Descrizione.TabIndex = 20;
            // 
            // tabGestionePrenotazione
            // 
            this.tabGestionePrenotazione.Controls.Add(this.tabGestionePrenotazione_Prenotazione);
            this.tabGestionePrenotazione.Controls.Add(this.tabGestionePrenotazione_Camere);
            this.tabGestionePrenotazione.Dock = Wisej.Web.DockStyle.Fill;
            this.tabGestionePrenotazione.Location = new System.Drawing.Point(0, 70);
            this.tabGestionePrenotazione.Name = "tabGestionePrenotazione";
            this.tabGestionePrenotazione.PageInsets = new Wisej.Web.Padding(1, 40, 1, 1);
            this.tabGestionePrenotazione.Size = new System.Drawing.Size(851, 527);
            this.tabGestionePrenotazione.TabIndex = 22;
            this.tabGestionePrenotazione.Selected += new Wisej.Web.TabControlEventHandler(this.tabGestionePrenotazione_Selected);
            // 
            // tabGestionePrenotazione_Prenotazione
            // 
            this.tabGestionePrenotazione_Prenotazione.Controls.Add(this.pnlPrenotazione);
            this.tabGestionePrenotazione_Prenotazione.Controls.Add(this.dgv_PrenotazioneCamera);
            this.tabGestionePrenotazione_Prenotazione.Location = new System.Drawing.Point(1, 40);
            this.tabGestionePrenotazione_Prenotazione.Name = "tabGestionePrenotazione_Prenotazione";
            this.tabGestionePrenotazione_Prenotazione.Size = new System.Drawing.Size(849, 486);
            this.tabGestionePrenotazione_Prenotazione.Text = "Dati Prenotazione";
            // 
            // dgv_PrenotazioneCamera
            // 
            this.dgv_PrenotazioneCamera.Columns.AddRange(new Wisej.Web.DataGridViewColumn[] {
            this.dgvc_IdPrenotazione,
            this.dgvc_IdCamera,
            this.dgvc_DataInizio,
            this.dgvc_DataFine,
            this.dgvc_Prenotazione_Stato,
            this.dgvc_Note});
            this.dgv_PrenotazioneCamera.Location = new System.Drawing.Point(4, 171);
            this.dgv_PrenotazioneCamera.Name = "dgv_PrenotazioneCamera";
            this.dgv_PrenotazioneCamera.Size = new System.Drawing.Size(841, 310);
            this.dgv_PrenotazioneCamera.TabIndex = 22;
            // 
            // dgvc_IdPrenotazione
            // 
            this.dgvc_IdPrenotazione.DataPropertyName = "IdPrenotazione";
            this.dgvc_IdPrenotazione.HeaderText = "IdPrenotazione";
            this.dgvc_IdPrenotazione.Name = "dgvc_IdPrenotazione";
            this.dgvc_IdPrenotazione.ValueType = typeof(long);
            // 
            // dgvc_IdCamera
            // 
            this.dgvc_IdCamera.DataPropertyName = "IdCamera";
            this.dgvc_IdCamera.DisplayMember = "NomeCompleto";
            this.dgvc_IdCamera.HeaderText = "Id Camera";
            this.dgvc_IdCamera.Name = "dgvc_IdCamera";
            this.dgvc_IdCamera.ValueMember = "IdCamera";
            this.dgvc_IdCamera.ValueType = typeof(string);
            // 
            // dgvc_DataInizio
            // 
            this.dgvc_DataInizio.DataPropertyName = "DataInizio";
            dataGridViewCellStyle1.Format = "d";
            this.dgvc_DataInizio.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvc_DataInizio.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dgvc_DataInizio.HeaderText = "Data Inizio";
            this.dgvc_DataInizio.Name = "dgvc_DataInizio";
            // 
            // dgvc_DataFine
            // 
            this.dgvc_DataFine.DataPropertyName = "DataFine";
            dataGridViewCellStyle2.Format = "d";
            this.dgvc_DataFine.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvc_DataFine.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dgvc_DataFine.HeaderText = "Data Fine";
            this.dgvc_DataFine.Name = "dgvc_DataFine";
            // 
            // dgvc_Prenotazione_Stato
            // 
            this.dgvc_Prenotazione_Stato.DataPropertyName = "Stato";
            this.dgvc_Prenotazione_Stato.HeaderText = "Stato";
            this.dgvc_Prenotazione_Stato.Name = "dgvc_Prenotazione_Stato";
            // 
            // dgvc_Note
            // 
            this.dgvc_Note.AutoSizeMode = Wisej.Web.DataGridViewAutoSizeColumnMode.Fill;
            this.dgvc_Note.DataPropertyName = "Note";
            this.dgvc_Note.HeaderText = "Note";
            this.dgvc_Note.Multiline = true;
            this.dgvc_Note.Name = "dgvc_Note";
            // 
            // tabGestionePrenotazione_Camere
            // 
            this.tabGestionePrenotazione_Camere.Location = new System.Drawing.Point(1, 40);
            this.tabGestionePrenotazione_Camere.Name = "tabGestionePrenotazione_Camere";
            this.tabGestionePrenotazione_Camere.Size = new System.Drawing.Size(849, 486);
            this.tabGestionePrenotazione_Camere.Text = "Camere";
            // 
            // vPrenotazione
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 19F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(851, 597);
            this.Controls.Add(this.tabGestionePrenotazione);
            this.Controls.Add(this.dataNavigator1);
            this.Name = "vPrenotazione";
            this.Text = "Scheda Prenotazione";
            this.Load += new System.EventHandler(this.vPrenotazione_Load);
            this.Resize += new System.EventHandler(this.vPrenotazione_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.bsPrenotazione)).EndInit();
            this.pnlPrenotazione.ResumeLayout(false);
            this.pnlPrenotazione.PerformLayout();
            this.tabGestionePrenotazione.ResumeLayout(false);
            this.tabGestionePrenotazione_Prenotazione.ResumeLayout(false);
            this.tabGestionePrenotazione_Prenotazione.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PrenotazioneCamera)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Passero.Framework.Controls.DataNavigator dataNavigator1;
        private Wisej.Web.BindingSource bsPrenotazione;
        private Wisej.Web.DateTimePicker dtpPrenotazione_DataPrenotazione;
        private Wisej.Web.TextBox txtPrenotazione_IdPrenotazione;
        private Wisej.Web.DateTimePicker dtpPrenotazione_DataInizio;
        private Wisej.Web.DateTimePicker dtpPrenotazione_DataFine;
        private Wisej.Web.ComboBox cmbPrenotazione_IdCliente;
        private Wisej.Web.ComboBox comboBox1;
        private Wisej.Web.FlowLayoutPanel  pnlPrenotazione;
        private Wisej.Web.TextBox txtPrenotazione_Descrizione;
        private Wisej.Web.TabControl tabGestionePrenotazione;
        private Wisej.Web.TabPage tabGestionePrenotazione_Prenotazione;
        private Wisej.Web.TabPage tabGestionePrenotazione_Camere;
        private Wisej.Web.DataGridView dgv_PrenotazioneCamera;
        private Wisej.Web.DataGridViewTextBoxColumn dgvc_IdPrenotazione;
        private Wisej.Web.DataGridViewComboBoxColumn dgvc_IdCamera;
        private Wisej.Web.DataGridViewDateTimePickerColumn dgvc_DataInizio;
        private Wisej.Web.DataGridViewDateTimePickerColumn dgvc_DataFine;
        private Wisej.Web.DataGridViewTextBoxColumn dgvc_Note;
        private Wisej.Web.DataGridViewTextBoxColumn dgvc_Prenotazione_Stato;
    }
}