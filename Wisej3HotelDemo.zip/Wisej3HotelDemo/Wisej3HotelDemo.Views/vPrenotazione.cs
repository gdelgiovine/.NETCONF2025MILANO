﻿using Wisej3HotelDemo.ViewModels;
using System;
using System.Data;
using Wisej.Web;
using System.Collections.Generic;
using Wisej.Hybrid;

using Passero.Framework.Controls;
using System.Linq;

namespace Wisej3HotelDemo.Views
{
    public partial class vPrenotazione : Form
    {
        public Passero.Framework.ConfigurationManager ConfigurationManager = new Passero.Framework.ConfigurationManager();
        private vmPrenotazione vmPrenotazione = new vmPrenotazione();
        private vmCalendarioCamera vmPrenotazioneCamera = new vmCalendarioCamera();
        private vmCliente vmCliente = new vmCliente();
        private vmCanalePrenotazione vmCanalePrenotazione = new vmCanalePrenotazione();
        private vmCamera vmCamera = new vmCamera();
        private IDbConnection DBConnectionHotelDemo;
        private IList<Models.Cliente> ElencoClienti = new List<Models.Cliente>();
        private IList<Models.CanalePrenotazione> ElencoCanaliPrenotazione = new List<Models.CanalePrenotazione>();
        private IList<Models.Camera> ElencoCamere = new List<Models.Camera>();

        private bool CreataDaPannelloPrenotazioni = false;
        private string IdCamera = string.Empty;
        public vPrenotazione()
        {
            InitializeComponent();

        }

        public void Init()
        {
            this.DBConnectionHotelDemo = this.ConfigurationManager.DBConnections["HotelDemo"];
           
            vmPrenotazione.Init(DBConnectionHotelDemo);
            vmPrenotazione.DataBindingMode = Passero.Framework.DataBindingMode.BindingSource;
            vmPrenotazione.BindingSource = this.bsPrenotazione;

            vmPrenotazioneCamera.Init(DBConnectionHotelDemo);
            vmCamera.Init(DBConnectionHotelDemo);
            vmCliente.Init(DBConnectionHotelDemo);
            vmCanalePrenotazione.Init(DBConnectionHotelDemo);


            this.ElencoClienti = vmCliente.GetAllItems().Value;
            this.ElencoCanaliPrenotazione = vmCanalePrenotazione.GetAllItems().Value;
            this.ElencoCamere = vmCamera.GetAllItems().Value;

            this.cmbPrenotazione_IdCliente.DataSource = ElencoClienti;
            this.cmbPrenotazione_IdCliente.DisplayMember = "NomeCompleto";
            this.cmbPrenotazione_IdCliente.ValueMember = "IdCliente";

            this.comboBox1.DataSource = ElencoCanaliPrenotazione;
            this.comboBox1.DisplayMember = "NomeCompleto";
            this.comboBox1.ValueMember = "IdCanale";

            this.dgvc_IdCamera.DataSource = ElencoCamere;
            this.dgvc_IdCamera.DisplayMember = "NomeCompleto";
            this.dgvc_IdCamera.ValueMember = "IdCamera";

            this.dgv_PrenotazioneCamera.AutoGenerateColumns = false;
            this.dataNavigator1.ViewModels["Prenotazione"] = new Passero.Framework.Controls.DataNavigatorViewModel(this.vmPrenotazione, "Prenotazione");
            this.dataNavigator1.ViewModels["PrenotazioneCamera"] = new Passero.Framework.Controls.DataNavigatorViewModel(this.vmPrenotazioneCamera, "PrenotazioneCamera","",this.dgv_PrenotazioneCamera );

            this.dataNavigator1.SetActiveViewModel("Prenotazione");
            this.dataNavigator1.ManageNavigation = true;
            this.dataNavigator1.ManageChanges = true;
            this.dataNavigator1.Init(true);
        }

        

        private void vPrenotazione_Load(object sender, EventArgs e)
        {
            this.Init();
        }
        public void ApriSchedaPrenotazione(int IdPrenotazione)
        {

            this.vmPrenotazione.GetPrenotazione(IdPrenotazione);

        }

        public void CreaNuovaPrenotazioneCamera(string IdCamera)
        {

            this.dataNavigator1 .SetActiveViewModel("Prenotazione");
            this.IdCamera = IdCamera;   
            this.CreataDaPannelloPrenotazioni = true;
            this.Show();
            this.dataNavigator1.AddNew(null, true);



        }

        private void tabGestionePrenotazione_Selected(object sender, TabControlEventArgs e)
        {
            if (e.TabPage == this.tabGestionePrenotazione_Prenotazione)
            {
                this.dataNavigator1.SetActiveViewModel("Prenotazione");
                
                this.pnlPrenotazione.Parent = this.tabGestionePrenotazione_Prenotazione;
                this.pnlPrenotazione.Enabled = true;
                this.dgv_PrenotazioneCamera.Parent = this.tabGestionePrenotazione_Prenotazione;
                this.dgv_PrenotazioneCamera.ReadOnly = true;
            
               

            }
            else if (e.TabPage == this.tabGestionePrenotazione_Camere)
            {
                this.dataNavigator1.SetActiveViewModel("PrenotazioneCamera");
                this.pnlPrenotazione.Parent = this.tabGestionePrenotazione_Camere;
                this.pnlPrenotazione.Enabled = false;
                this.dgv_PrenotazioneCamera.Parent = this.tabGestionePrenotazione_Camere;
                this.dgv_PrenotazioneCamera.ReadOnly = false;
            }

            

        }

        private void dataNavigator1_eBoundCompleted()
        {
            if (this.dataNavigator1.ActiveViewModelIs(this.vmPrenotazione ) )
            {
                //this.dgv_PrenotazioneCamera.DataSource = this.vmPrenotazioneCamera.GetCamerePrenotazione(Convert.ToInt32(this.txtPrenotazione_IdPrenotazione.Text));
            }

        }

        private void txtPrenotazione_IdPrenotazione_TextChanged(object sender, EventArgs e)
        {
            this.dgv_PrenotazioneCamera.DataSource = this.vmPrenotazioneCamera.GetCamerePrenotazione(Convert.ToInt32(this.txtPrenotazione_IdPrenotazione.Text));
        }

        private void dataNavigator1_eAddNewRequest(ref bool Cancel)
        {
            
        }

        private void dataNavigator1_eAfterAddNewRequest(ref bool Cancel)
        {
            if (dataNavigator1 .ActiveViewModelIs(this.vmPrenotazioneCamera))
            {

                DataGridViewRow newrow = this.dgv_PrenotazioneCamera.CurrentRow;
                newrow[this.dgvc_IdPrenotazione].Value = vmPrenotazione.ModelItem .IdPrenotazione ;
                newrow[this.dgvc_DataInizio].Value = vmPrenotazione.ModelItem.DataInizio ;
                newrow[this.dgvc_DataFine].Value = vmPrenotazione.ModelItem.DataFine ;
                if (this.CreataDaPannelloPrenotazioni)
                {
                    newrow[this.dgvc_IdCamera].Value = this.IdCamera;
                    this.CreataDaPannelloPrenotazioni = false;
                }
                
                this.dgv_PrenotazioneCamera.CurrentCell = this.dgv_PrenotazioneCamera.CurrentRow[this.dgvc_IdCamera];
                this.dgv_PrenotazioneCamera.BeginEdit();    
            }   
        }

      

    

        private void pnlPrenotazione_Resize(object sender, EventArgs e)
        {
          
        }

        private void vPrenotazione_Resize(object sender, EventArgs e)
        {
            this.dgv_PrenotazioneCamera.Top = this.pnlPrenotazione.Bottom;
            this.dgv_PrenotazioneCamera .Height = this.tabGestionePrenotazione.Height - this.pnlPrenotazione.Height - 20;
            this.dgv_PrenotazioneCamera.Width = this.tabGestionePrenotazione.Width;
            this.dgv_PrenotazioneCamera .Left = 0;

        }
    }
}
