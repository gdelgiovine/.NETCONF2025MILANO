﻿using Wisej3HotelDemo.ViewModels;
using Passero.Framework;
using Passero.Framework.Controls;
using System;
using System.Data;
using System.Runtime.CompilerServices;
using Wisej.Web;

namespace Wisej3HotelDemo.Views
{
    public partial class vCliente : Form
    {

        public Passero.Framework.ConfigurationManager ConfigurationManager = new Passero.Framework.ConfigurationManager();
        private vmCliente vmCliente  = new vmCliente();  
        private IDbConnection  DBConnectionHotelDemo;
        public vCliente()
        {
            InitializeComponent();
        }

        public void Init()
        {
            this.DBConnectionHotelDemo = this.ConfigurationManager.DBConnections["HotelDemo"];
            vmCliente.Init(DBConnectionHotelDemo );
            vmCliente.DataBindingMode = Passero.Framework.DataBindingMode.BindingSource;
            vmCliente.BindingSource = this.bsCliente ;

            this.dataNavigator1.ViewModels["Cliente"] = new Passero.Framework.Controls.DataNavigatorViewModel(this.vmCliente, "Cliente");
            this.dataNavigator1.SetActiveViewModel("Cliente");
            this.dataNavigator1.ManageNavigation = true;
            this.dataNavigator1.ManageChanges = true;
            this.dataNavigator1.Init(false);
        }

        private void QBE_Clienti()
        {
            QBEForm<Models.Cliente > QBE = new QBEForm<Models.Cliente >(this.DBConnectionHotelDemo, this);
            QBE.QBEResultMode = QBEResultMode.MultipleRowsSQLQuery;
            QBE.QBEModelPropertiesMapping.Add(nameof(Models.Cliente.IdCliente ), nameof(Models.Cliente .IdCliente ));
            QBE.SetTargetViewModel(this.vmCliente , () => this.dataNavigator1 .Init(true));
            QBE.ShowQBE();
        }

        private void vCliente_Load(object sender, EventArgs e)
        {
            this.Init();
        }

        private void dataNavigator1_eFind()
        {
            QBE_Clienti (); 
        }
    }
}
