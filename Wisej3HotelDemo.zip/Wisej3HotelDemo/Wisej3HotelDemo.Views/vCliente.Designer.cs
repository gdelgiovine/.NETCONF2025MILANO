﻿namespace Wisej3HotelDemo.Views
{
    partial class vCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej.NET Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtCliente_Id = new Wisej.Web.TextBox();
            this.bsCliente = new Wisej.Web.BindingSource(this.components);
            this.txtCliente_Cognome = new Wisej.Web.TextBox();
            this.txtCliente_Nome = new Wisej.Web.TextBox();
            this.dataNavigator1 = new Passero.Framework.Controls.DataNavigator();
            this.dtpCliente_DataRegistrazione = new Wisej.Web.DateTimePicker();
            this.txtCliente_Indirizzo = new Wisej.Web.TextBox();
            this.txtCliente_Email = new Wisej.Web.TextBox();
            this.txtCliente_Telefono = new Wisej.Web.TextBox();
            this.flowLayoutPanel1 = new Wisej.Web.FlowLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.bsCliente)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtCliente_Id
            // 
            this.txtCliente_Id.DataBindings.Add(new Wisej.Web.Binding("Text", this.bsCliente, "IdCliente", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.txtCliente_Id.Focusable = false;
            this.txtCliente_Id.LabelText = "Id Cliente";
            this.txtCliente_Id.Location = new System.Drawing.Point(3, 3);
            this.txtCliente_Id.Name = "txtCliente_Id";
            this.txtCliente_Id.ReadOnly = true;
            this.txtCliente_Id.Size = new System.Drawing.Size(100, 53);
            this.txtCliente_Id.TabIndex = 1;
            // 
            // bsCliente
            // 
            this.bsCliente.DataSource = typeof(Wisej3HotelDemo.Models.Cliente);
            // 
            // txtCliente_Cognome
            // 
            this.txtCliente_Cognome.DataBindings.Add(new Wisej.Web.Binding("Text", this.bsCliente, "Cognome", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.flowLayoutPanel1.SetFillWeight(this.txtCliente_Cognome, 40);
            this.txtCliente_Cognome.LabelText = "Cognome";
            this.txtCliente_Cognome.Location = new System.Drawing.Point(109, 3);
            this.txtCliente_Cognome.MaximumSize = new System.Drawing.Size(300, 0);
            this.txtCliente_Cognome.MinimumSize = new System.Drawing.Size(100, 0);
            this.txtCliente_Cognome.Name = "txtCliente_Cognome";
            this.txtCliente_Cognome.Size = new System.Drawing.Size(300, 53);
            this.txtCliente_Cognome.TabIndex = 2;
            // 
            // txtCliente_Nome
            // 
            this.txtCliente_Nome.DataBindings.Add(new Wisej.Web.Binding("Text", this.bsCliente, "Nome", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.flowLayoutPanel1.SetFillWeight(this.txtCliente_Nome, 40);
            this.flowLayoutPanel1.SetFlowBreak(this.txtCliente_Nome, true);
            this.txtCliente_Nome.LabelText = "Nome";
            this.txtCliente_Nome.Location = new System.Drawing.Point(415, 3);
            this.txtCliente_Nome.MaximumSize = new System.Drawing.Size(300, 0);
            this.txtCliente_Nome.MinimumSize = new System.Drawing.Size(100, 0);
            this.txtCliente_Nome.Name = "txtCliente_Nome";
            this.txtCliente_Nome.Size = new System.Drawing.Size(300, 53);
            this.txtCliente_Nome.TabIndex = 3;
            // 
            // dataNavigator1
            // 
            this.dataNavigator1.Caption = "Clienti";
            this.dataNavigator1.Dock = Wisej.Web.DockStyle.Top;
            this.dataNavigator1.Name = "dataNavigator1";
            this.dataNavigator1.Size = new System.Drawing.Size(852, 70);
            this.dataNavigator1.TabIndex = 0;
            this.dataNavigator1.eFind += new Passero.Framework.Controls.DataNavigator.eFindEventHandler(this.dataNavigator1_eFind);
            // 
            // dtpCliente_DataRegistrazione
            // 
            this.dtpCliente_DataRegistrazione.DataBindings.Add(new Wisej.Web.Binding("NullableValue", this.bsCliente, "DataRegistrazione", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.dtpCliente_DataRegistrazione.Format = Wisej.Web.DateTimePickerFormat.Short;
            this.dtpCliente_DataRegistrazione.LabelText = "Data Registrazione";
            this.dtpCliente_DataRegistrazione.Location = new System.Drawing.Point(3, 180);
            this.dtpCliente_DataRegistrazione.Name = "dtpCliente_DataRegistrazione";
            this.dtpCliente_DataRegistrazione.Size = new System.Drawing.Size(117, 53);
            this.dtpCliente_DataRegistrazione.TabIndex = 4;
            // 
            // txtCliente_Indirizzo
            // 
            this.txtCliente_Indirizzo.DataBindings.Add(new Wisej.Web.Binding("Text", this.bsCliente, "Indirizzo", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.flowLayoutPanel1.SetFillWeight(this.txtCliente_Indirizzo, 100);
            this.flowLayoutPanel1.SetFlowBreak(this.txtCliente_Indirizzo, true);
            this.txtCliente_Indirizzo.LabelText = "Indirizzo";
            this.txtCliente_Indirizzo.Location = new System.Drawing.Point(3, 62);
            this.txtCliente_Indirizzo.MaximumSize = new System.Drawing.Size(400, 0);
            this.txtCliente_Indirizzo.Name = "txtCliente_Indirizzo";
            this.txtCliente_Indirizzo.Size = new System.Drawing.Size(400, 53);
            this.txtCliente_Indirizzo.TabIndex = 5;
            // 
            // txtCliente_Email
            // 
            this.txtCliente_Email.DataBindings.Add(new Wisej.Web.Binding("Text", this.bsCliente, "Email", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.flowLayoutPanel1.SetFlowBreak(this.txtCliente_Email, true);
            this.txtCliente_Email.LabelText = "Email";
            this.txtCliente_Email.Location = new System.Drawing.Point(254, 121);
            this.txtCliente_Email.Name = "txtCliente_Email";
            this.txtCliente_Email.Size = new System.Drawing.Size(245, 53);
            this.txtCliente_Email.TabIndex = 6;
            // 
            // txtCliente_Telefono
            // 
            this.txtCliente_Telefono.DataBindings.Add(new Wisej.Web.Binding("Text", this.bsCliente, "Telefono", true, Wisej.Web.DataSourceUpdateMode.OnValidation, null, ""));
            this.txtCliente_Telefono.LabelText = "Telefono";
            this.txtCliente_Telefono.Location = new System.Drawing.Point(3, 121);
            this.txtCliente_Telefono.Name = "txtCliente_Telefono";
            this.txtCliente_Telefono.Size = new System.Drawing.Size(245, 53);
            this.txtCliente_Telefono.TabIndex = 7;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.txtCliente_Id);
            this.flowLayoutPanel1.Controls.Add(this.txtCliente_Cognome);
            this.flowLayoutPanel1.Controls.Add(this.txtCliente_Nome);
            this.flowLayoutPanel1.Controls.Add(this.txtCliente_Indirizzo);
            this.flowLayoutPanel1.Controls.Add(this.txtCliente_Telefono);
            this.flowLayoutPanel1.Controls.Add(this.txtCliente_Email);
            this.flowLayoutPanel1.Controls.Add(this.dtpCliente_DataRegistrazione);
            this.flowLayoutPanel1.Dock = Wisej.Web.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 70);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(852, 453);
            this.flowLayoutPanel1.TabIndex = 8;
            // 
            // vCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 19F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(852, 523);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.dataNavigator1);
            this.Name = "vCliente";
            this.Text = "Scheda Cliente";
            this.Load += new System.EventHandler(this.vCliente_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bsCliente)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Passero.Framework.Controls.DataNavigator dataNavigator1;
        private Wisej.Web.BindingSource bsCliente;
        private Wisej.Web.TextBox txtCliente_Id;
        private Wisej.Web.TextBox txtCliente_Cognome;
        private Wisej.Web.TextBox txtCliente_Nome;
        private Wisej.Web.DateTimePicker dtpCliente_DataRegistrazione;
        private Wisej.Web.TextBox txtCliente_Indirizzo;
        private Wisej.Web.TextBox txtCliente_Email;
        private Wisej.Web.TextBox txtCliente_Telefono;
        private Wisej.Web.FlowLayoutPanel flowLayoutPanel1;
    }
}