﻿namespace Wisej3HotelDemo.Controls
{
    partial class CtlElementoCalendario
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej.NET Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Wisej.Web.ComponentTool componentTool1 = new Wisej.Web.ComponentTool();
            Wisej.Web.ComponentTool componentTool2 = new Wisej.Web.ComponentTool();
            Wisej.Web.ComponentTool componentTool3 = new Wisej.Web.ComponentTool();
            Wisej.Web.ComponentTool componentTool4 = new Wisej.Web.ComponentTool();
            this.InnerControl = new Wisej.Web.TextBox();
            this.SuspendLayout();
            // 
            // InnerControl
            // 
            this.InnerControl.AutoSize = false;
            this.InnerControl.BackColor = System.Drawing.Color.MintCream;
            this.InnerControl.CssStyle = "border-top-left-radius: 30px;\r\nborder-top-right-radius: 10px;\r\nborder-bottom-righ" +
    "t-radius: 30px;\r\nborder-bottom-left-radius: 10px;";
            this.InnerControl.Focusable = false;
            this.InnerControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.InnerControl.Location = new System.Drawing.Point(3, 3);
            this.InnerControl.Margin = new Wisej.Web.Padding(0);
            this.InnerControl.Name = "InnerControl";
            this.InnerControl.ReadOnly = true;
            this.InnerControl.Size = new System.Drawing.Size(121, 26);
            this.InnerControl.TabIndex = 0;
            this.InnerControl.TabStop = false;
            this.InnerControl.Text = "ACognome";
            componentTool1.ImageSource = "icon-question";
            componentTool1.Name = "Info";
            componentTool1.Position = Wisej.Web.LeftRightAlignment.Left;
            componentTool1.ToolTipText = "Informazioni sulla Prenotazione";
            componentTool2.ImageSource = "resource.wx/Wisej.Ext.BootstrapIcons/person-check-fill.svg";
            componentTool2.Name = "CheckIn";
            componentTool2.Position = Wisej.Web.LeftRightAlignment.Left;
            componentTool2.ToolTipText = "Dettagli sul CheckIn";
            componentTool2.Visible = false;
            componentTool3.ImageSource = "file-excel";
            componentTool3.Name = "Canale";
            componentTool3.Position = Wisej.Web.LeftRightAlignment.Left;
            componentTool3.ToolTipText = "Canale origine Prenotazione";
            componentTool4.ImageSource = "node-closed";
            componentTool4.Name = "CheckOut";
            componentTool4.ToolTipText = "Esegue il CheckOut";
            this.InnerControl.Tools.AddRange(new Wisej.Web.ComponentTool[] {
            componentTool1,
            componentTool2,
            componentTool3,
            componentTool4});
            this.InnerControl.ToolClick += new Wisej.Web.ToolClickEventHandler(this.InnerControl_ToolClick);
            // 
            // CtlPrenotazioneE
            // 
            this.Anchor = ((Wisej.Web.AnchorStyles)((((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Bottom) 
            | Wisej.Web.AnchorStyles.Left) 
            | Wisej.Web.AnchorStyles.Right)));
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.InnerControl);
            this.CssStyle = "border-radius: 0px;\r\n";
            this.Name = "CtlElementoCalendario";
            this.Size = new System.Drawing.Size(127, 31);
            this.Resize += new System.EventHandler(this.CtlElementoCalendario_Resize);
            this.ResumeLayout(false);

        }

        #endregion

        public Wisej.Web.TextBox InnerControl;
    }
}
